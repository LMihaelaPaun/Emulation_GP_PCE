%% Run the 1D model with the parameter estimates from the emulator
clc; clear all; %close all;
%% Define scaling factors for resistance/compliance if needed
% five parameter set, k1, k2, rp, rd, and c; k3 = 0
k1 = 1e5;
k2 = -20;
k3 = 0.0;
rp = 1.0;
rd = 1.0;
c  = 1.0;

pars = [k1 k2 k3 ...
        rp rd c 1];
pars_str = mat2str(pars);
%% call the model

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
unix(sprintf('sor06.exe  %s',pars_str(2:end-1)));
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Plotting Simulated data
% Plot inlet/outlet waveforms in the whole tree
fname_load = strcat('pu_ALL_',num2str(1),'.2d');
data = load(fname_load);
% data = dlmread('art_ALL.2d');
[~,~,p,~,~,~] = gnuplot(data);


figure; plot(p);




