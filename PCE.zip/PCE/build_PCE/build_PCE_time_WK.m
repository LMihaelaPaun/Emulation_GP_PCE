%%
clearvars
rng(100,'twister')
uqlab
num_samp = 1000;
pce_deg = 6;

Names_ALL = {'f1','f2','f3','r1','r2','c'};
folder_name = 'final_WK_PCE/';
counter = 1;

load ../Data_Files/WK_5par_train.mat
load ../Data_Files/WK_5par_test.mat
Names = Names_ALL([1 2 4 5 6]);
low = [30000 -30 0.05 0.05 0.05];
upp = [200000 -10 3   3     3];
fname1 = strcat('PCE_WK_5par_',num2str(num_samp),'_deg',num2str(pce_deg));

par_train = par_train(1:num_samp,:);
p_train   = p_train(:,1:num_samp);

MetaOpts.Display = 'quiet';
[num_samp,num_par] = size(par_train);

Input = [];
% Define an INPUT object with the following marginals:
for i=1:num_par
    Input.Marginals(i).Name = Names{i};  % beam width
    Input.Marginals(i).Type = 'Uniform';
    Input.Marginals(i).Parameters = [low(i) upp(i)];  % (m)
end
myInput = uq_createInput(Input);

% Data
N_train   = num_samp;
X_train   = par_train;
Y_train   = p_train(1:8:end,:)';
X_test    = par_test;
Y_test    = p_test(1:8:end,:)';
N_time    = size(Y_train,2);

% Add more testing data?


%%
MetaOpts.Type = 'Metamodel';
MetaOpts.MetaType = 'PCE';
MetaOpts.Degree = pce_deg;

MetaOpts.ExpDesign.X = X_train;
MetaOpts.ExpDesign.Y = Y_train;
%     MetaOpts.Bootstrap.Replications = 50;

MetaOpts.Method = 'OLS';
fname = strcat(folder_name,fname1,'_OLS');

%%
% Create the PCE metamodel:
myPCE = uq_createModel(MetaOpts);

%%
t = 1:N_time; % Arbitrary time
mu_PCE  = zeros(N_time,1);
std_PCE = zeros(N_time,1);

for i=1:N_time
    mu_PCE(i) = myPCE.PCE(i).Moments.Mean;
    std_PCE(i) = sqrt(myPCE.PCE(i).Moments.Var);
end
PCE_p = mu_PCE+std_PCE;
PCE_m = mu_PCE-std_PCE;

figure(1); hold on;
fill([t'; fliplr(t)'],[PCE_p; flipud(PCE_m)],[0.9 0.6 0.6],'EdgeAlpha',0,'FaceAlpha',0.4);
uq_plot(1:N_time,mu_PCE,'k','LineWidth',3);
set(gca,'FontSize',30); grid on;
ylabel('Pressure (mmHg)');
xticks([1 16 32]); xticklabels({'0','T/2','T'});

%% Test out of sample points
Y_PCE = uq_evalModel(X_test);
RSS = sum((Y_PCE-Y_test).^2,2);
MSE = RSS./N_time;

%% Save emulator
% save(fname,'myPCE','upp','low','Names');

%% SENSITIVITY
num_par = size(myPCE.ExpDesign.X,2);



MetaOpts.Type = 'Metamodel';
MetaOpts.MetaType = 'PCE';
MetaOpts.Degree = myPCE.Options.Degree;
MetaOpts.Method = myPCE.Options.Method;
MetaOpts.ExpDesign.X = myPCE.ExpDesign.X;
MetaOpts.ExpDesign.Y = myPCE.ExpDesign.Y;

PCESobol.Type = 'Sensitivity';
PCESobol.Method = 'Sobol';
PCESobol.Sobol.Order = 4;

% myPCE_OLS = uq_createModel(MetaOpts);
myPCE_OLS = myPCE;

Input = myPCE.Internal.Input;
%%

PCESobol.PCE.CustomPCE = myPCE;
PCESobol.Input = Input;
PCESobol.Model = myPCE;
Sobol_P = uq_createAnalysis(PCESobol);

%% Plot the sobol results
Ids_2nd = Sobol_P.Results.VarIdx{2};
Ids_3rd = Sobol_P.Results.VarIdx{3};
Ids_4th = Sobol_P.Results.VarIdx{4};

figure(2);
plot(Sobol_P.Results.Total','LineWidth',3);
legend(Names);
set(gca,'FontSize',20);
grid on;
% set(gcf,'Position',[-1.4062e+03 275.4000 560 420.0000])
%%
% h = hsv((120));
% figure(2); clf; hold on;
Names_2 = {};
for i=1:length(Ids_2nd)
    new_name = strcat(Names{Ids_2nd(i,1)},'-',Names{Ids_2nd(i,2)});
    Names_2{end+1} = new_name;
%     plot(Sobol_P.Results.AllOrders{2}(i,:),'LineWidth',3,'Color',h(i,:));
    
end
% legend(Names_2);
% set(gca,'FontSize',20);
% grid on;
% set(gcf,'Position',[-1.4062e+03 275.4000 560 420.0000])
%%
% h = hsv((120));
% figure(3); clf; hold on;
Names_3 = {};
for i=1:length(Ids_3rd)
    new_name = strcat(Names{Ids_3rd(i,1)},'-',Names{Ids_3rd(i,2)},'-',Names{Ids_3rd(i,3)});
    Names_3{end+1} = new_name;
%     plot(Sobol_P.Results.AllOrders{3}(i,:),'LineWidth',3,'Color',h(i,:));
    
end
% legend(Names_3);
% set(gca,'FontSize',20);
% grid on;
% set(gcf,'Position',[-1.4062e+03 275.4000 560 420.0000])
%% Get Generalized Sobol Indices
nt = 32;
pce_var = Sobol_P.Results.TotalVariance;
GS_T = zeros(nt,num_par);
GS_1 = zeros(nt,num_par);
GS_2 = zeros(nt,length(Ids_2nd));
GS_3 = zeros(nt,length(Ids_3rd));
GS_4 = zeros(nt,length(Ids_4th));

for i=1:nt
    int_var = trapz(pce_var(1:i));
    GS_T(i,:)    = trapz(pce_var(1:i)'.* Sobol_P.Results.Total(:,1:i)')./int_var;
    GS_1(i,:)    = trapz(pce_var(1:i)'.* Sobol_P.Results.AllOrders{1}(:,1:i)')./int_var;
    GS_2(i,:)    = trapz(pce_var(1:i)'.* Sobol_P.Results.AllOrders{2}(:,1:i)')./int_var;
    GS_3(i,:)    = trapz(pce_var(1:i)'.* Sobol_P.Results.AllOrders{3}(:,1:i)')./int_var;
    GS_4(i,:)    = trapz(pce_var(1:i)'.* Sobol_P.Results.AllOrders{4}(:,1:i)')./int_var;
end
% uq_print(Sobol_P);

%%
figure(10);clf;hold on;
bar([GS_1(end,:); GS_T(end,:)-GS_1(end,:); GS_T(end,:)]');
xticks(1:num_par); xticklabels(Names)
% legend('$S_1$','Higher Order','$S_T$','Location','bestoutside')
set(gca,'FontSize',20);
grid on;
% Big figure only (with legend)
% set(gcf,'Position',[-2.1660e+02   1.3418e+03   1.4776e+03   4.6240e+02])
% Smaller figures
set(gcf,'Position',[-2.1660e+02   1.3418e+03   1.0288e+03   4.6240e+02]);
%%

figure(30); title('Second');
bar(GS_2(end,:));
xticks(1:length(Ids_2nd)); xticklabels(Names_2)
set(gca,'FontSize',12);

grid on;
% set(gcf,'Position',[-1.4062e+03 275.4000 560 420.0000])

% figure(40); title('Third');
% bar(GS_3(end,:));
% xticks(1:length(Ids_3rd)); xticklabels(Names_3)
% set(gca,'FontSize',20);
% grid on;
% set(gcf,'Position',[-1.4062e+03 275.4000 560 420.0000])



