%%
clearvars
rng(100,'twister')
uqlab
num_samp = 1000;
pce_deg = 6;

Names_ALL = {'f1','f2','f3','r1','r2','c'};
folder_name = 'final_WK_PCE/';
counter = 1;

load ../Data_Files/WK_5par_PCA.mat
load ../Data_Files/WK_5par_test.mat
Names = Names_ALL([1 2 4 5 6]);
low = [30000 -30 0.05 0.05 0.05];
upp = [200000 -10 3   3     3];
low = low./sc;
upp = upp./sc;

fname1 = strcat('PCE_PCA_WK_5par_',num2str(num_samp),'_deg',num2str(pce_deg));

par_train = x_PCA_train;
par_test  = x_PCA_test./sc;
p_train   = y_PCA_train';
p_test    = y_PCA_test';



par_train = par_train(1:num_samp,:);
p_train   = p_train(:,1:num_samp);

MetaOpts.Display = 'quiet';
[num_samp,num_par] = size(par_train);

Input = [];
% Define an INPUT object with the following marginals:
for i=1:num_par
    Input.Marginals(i).Name = Names{i};  % beam width
    Input.Marginals(i).Type = 'Uniform';
    Input.Marginals(i).Parameters = [low(i) upp(i)];  % (m)
end
myInput = uq_createInput(Input);

% Data
N_train   = num_samp;
X_train   = par_train;
Y_train   = p_train';
X_test    = par_test;
Y_test    = p_test';
N_time    = size(Y_train,2);

% Add more testing data?


%%
MetaOpts.Type = 'Metamodel';
MetaOpts.MetaType = 'PCE';
MetaOpts.Degree = pce_deg;

MetaOpts.ExpDesign.X = X_train;
MetaOpts.ExpDesign.Y = Y_train;
%     MetaOpts.Bootstrap.Replications = 50;

MetaOpts.Method = 'OLS';
fname = strcat(folder_name,fname1,'_OLS');

%%
% Create the PCE metamodel:
myPCE = uq_createModel(MetaOpts);

%%
t = 1:N_time; % Arbitrary time
mu_PCE  = zeros(N_time,1);
std_PCE = zeros(N_time,1);

for i=1:N_time
    mu_PCE(i) = myPCE.PCE(i).Moments.Mean;
    std_PCE(i) = sqrt(myPCE.PCE(i).Moments.Var);
end
PCE_p = mu_PCE+std_PCE;
PCE_m = mu_PCE-std_PCE;

%% Test out of sample points
Y_PCE = uq_evalModel(X_test)*PCE_coeff' + mu;
Y_time = Y_test*PCE_coeff' + mu;
RSS= sum((Y_PCE-Y_time).^2,2);
MSE = RSS./N_time;
%% Save emulator
save(fname,'myPCE','upp','low','Names');


