function [ObjFct,pressure] = Mitchel_Get_OF(param, data,myPCE,sc) %param is scaled

truePressure  = data;

% obtain pressure with emulator for param
pressure = uq_evalModel(myPCE,param.*sc);
    
% calculate RSS
ObjFct = sum((pressure(:)-truePressure(:)).^2);

end
