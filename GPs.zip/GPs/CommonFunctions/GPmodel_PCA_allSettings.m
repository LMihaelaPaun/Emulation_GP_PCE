function [gp, nlml] = GPmodel_PCA_allSettings(x, y, H, kernel_index, jitter)
% Fit and return GP regression model to x and y

% Hyperpriors
plg = prior_logunif(); % prior for lengthscale
pms = prior_logunif(); % prior for amplitude
%ps = prior_logunif(); % prior for sigma2 in the likelihood

for i = 1:size(H,1)
    lik = lik_gaussian('sigma2', 0, 'sigma2_prior', prior_fixed);
    
    if kernel_index == 1
        % use RBF
        gpcf = gpcf_sexp('lengthScale', H(i,2:end), ...
            'magnSigma2', H(i,1),...
            'lengthScale_prior', plg, 'magnSigma2_prior', pms);
        %
    elseif kernel_index == 2
        % Matern 5/2
        gpcf = gpcf_matern52('lengthScale', H(i,2:end), ...
            'magnSigma2', H(i,1),...
            'lengthScale_prior', plg, 'magnSigma2_prior', pms);
        %
    elseif kernel_index == 3
        % Matern 3/2
        gpcf = gpcf_matern32('lengthScale', H(i,2:end), ...
            'magnSigma2', H(i,1),...
            'lengthScale_prior', plg, 'magnSigma2_prior', pms);
        %
    else % neural network
        gpcf = gpcf_neuralnetwork('weightSigma2', 1./H(i,2:end), ...
            'biasSigma2', H(i,1),...
            'weightSigma2_prior', plg, 'biasSigma2_prior', pms);
    end
    
    gp_all{i} = gp_set('lik', lik, 'cf', gpcf, 'jitterSigma2', jitter);
    
    % Set the options for the optimization
    opt=optimset('TolFun',1e-6,'TolX',1e-6, 'MaxFunEvals',2000); %
    
    % Optimize with the scaled conjugate gradient method
    [gp_all{i}, nlml(i)] = gp_optim(gp_all{i},x,y,'opt',opt);
    
end

I = find(nlml == min(nlml(i)));
gp = gp_all{I};
disp('done')

end

