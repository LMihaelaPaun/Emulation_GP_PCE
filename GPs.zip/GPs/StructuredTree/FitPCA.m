clear

% add path to the original GPstuff toolbox (without the changes made to
% accommodate kronecker product for multioutput GP)
addpath(genpath('/GPstuff-4.7'))

addpath('/CommonFunctions')

noBeta = 1;

if noBeta == 1
    load('ST_4par_train.mat') % no rmin, beta out
else
    load('ST_normin_train.mat') % no rmin, beta in
end

nd = size(par_train,2);

n_train = size(par_train,1); % no of training points
x_train = par_train(1:n_train,:); % take a subset of all training points

if noBeta == 1
    l = [8e4 -30 0.80 3];
    u = [2e5 -5 0.92 10];
    
else
    
    l = [8e4 -30 0.80 0.60 3];
    u = [2e5 -5 0.92 0.72 10];
end

sc = max(abs(l),abs(u));

x_train = x_train./sc;

pressures_train=(p_train(:,1:n_train))';

pressures_train = pressures_train(:,1:8:end); % take every 8th point

ntp=size(pressures_train,2); % no of time points

% PCA data (take the same as training data)
n_PCA = n_train; % no of training points
x_PCA = x_train; % this is already scaled

% take the corresponding subset of pressures; only MPA pressure
pressures_PCA = pressures_train;

% PCA testing data
if noBeta == 1
    load('ST_4par_test.mat')
else
    load('ST_normin_test.mat')
end

n_test = size(par_test,1);
x_test = par_test;

x_test = x_test./sc;

pressures_test=p_test';

pressures_test = pressures_test(:,1:8:end); % take every 8th point

% fit PCA on data
[coeff,score,latent,tsquared,explained,mu] = pca(pressures_PCA);

meanMSE_PCA_train = NaN(min(size(coeff,2),20),1);

for NC = 1:(min(size(coeff,2),20))
    pressures_recons = score(:,1:NC)*coeff(:,1:NC)'+mu;
    
    MSE_PCA_train = sum((pressures_PCA - pressures_recons).^2,2);
    
    meanMSE_PCA_train(NC) = mean(MSE_PCA_train, "omitnan"); % !!! quantity of interest
end

% test PCA on test data
meanMSE_PCA_test = NaN(min(size(coeff,2),20),1);

for NC = 1:(min(size(coeff,2),20))
    PCscores_test = (pressures_test - mu)*coeff(:, 1:NC); % using only the first NC PCs
    
    pressures_test_PCA_recons = PCscores_test * coeff(:,1:NC)' + mu;
    
    MSE_PCA_test = sum((pressures_test- pressures_test_PCA_recons).^2,2);
    
    meanMSE_PCA_test(NC) = mean(MSE_PCA_test, "omitnan"); % !!! quantity of interest
end

figure;plot(meanMSE_PCA_train,'.');hold on;plot(meanMSE_PCA_test,'.')

NC = 5; % choose 5 PCs

PCscores_test = (pressures_test - mu)*coeff(:, 1:NC); % using only the first NC PCs

pressures_test_PCA_recons = PCscores_test * coeff(:,1:NC)' + mu;

figure(1);clf(1)
for i=21:30%n_test
    subplot(2,5,i-20);hold on
    plot(linspace(0,0.11,ntp),pressures_test(i,:), '-','linewidth', 3)
    plot(linspace(0,0.11,ntp),pressures_test_PCA_recons(i,:), '--','linewidth', 3)
end
legend('Original', 'Reconstructed')
title(sprintf('%d PCs', NC))

if noBeta == 1
    save('PCAresults_ST_noBeta.mat')
else
    save('PCAresults_ST_normin.mat')
end