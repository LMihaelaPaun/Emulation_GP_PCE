function [gp, nlml, gp1, gp2] = GPmodel_multioutput_allSettings(x, y, H, ...
    kernelCombo, jitter)
% Fit and return GP regression model to x and y
% Explores different combinations of kernel combos for parameter and time,
% as well as for jitter

[unq,ind_unq] = unique(x(:,1),'stable');
x1 = x(ind_unq,1:end-1);
x2 = unique(x(:,end),'stable');

% Hyperpriors
plg = prior_logunif(); % prior for lengthscale
pms = prior_logunif(); % prior for amplitude
%ps = prior_logunif(); % prior for sigma2 in the likelihood

for i = 1:size(H,1)
    %    lik = lik_gaussian('sigma2', H(i,end), 'sigma2_prior', ps);
    lik = lik_gaussian('sigma2', 0, 'sigma2_prior', prior_fixed);
    
    if kernelCombo == 1 % (Matern 5/2, periodic)
        
        gpcf1_v = gpcf_matern52('selectedVariables', [1:size(x,2)-1], 'lengthScale', H(i,2:1+size(x1,2)), ...
            'magnSigma2', H(i,1),...
            'lengthScale_prior', plg, 'magnSigma2_prior', pms);
        
        gpcf2_v = gpcf_periodic('selectedVariables', size(x,2), 'lengthScale', H(i,end), ...
            'magnSigma2', 1, 'period', 1, 'lengthScale_sexp', 1, 'decay', 0, ...
            'lengthScale_prior', plg, 'magnSigma2_prior', prior_fixed, ...
            'lengthScale_sexp_prior', prior_fixed, 'period_prior', prior_fixed);
        
        gpcf1 = gpcf_matern52('lengthScale', H(i,2:1+size(x1,2)), ...
            'magnSigma2', H(i,1),...
            'lengthScale_prior', plg, 'magnSigma2_prior', pms);
        
        gpcf2 = gpcf_periodic('lengthScale', H(i,end), ...
            'magnSigma2', 1, 'period', 1, 'lengthScale_sexp', 1, 'decay', 0, ...
            'lengthScale_prior', plg, 'magnSigma2_prior', prior_fixed, ...
            'lengthScale_sexp_prior', prior_fixed, 'period_prior', prior_fixed);
        %
    elseif kernelCombo == 2 % (Matern 3/2, periodic)
        
        gpcf1_v = gpcf_matern32('selectedVariables', [1:size(x,2)-1], 'lengthScale', H(i,2:1+size(x1,2)), ...
            'magnSigma2', H(i,1),...
            'lengthScale_prior', plg, 'magnSigma2_prior', pms);
        
        gpcf2_v = gpcf_periodic('selectedVariables', size(x,2), 'lengthScale', H(i,end), ...
            'magnSigma2', 1, 'period', 1, 'lengthScale_sexp', 1, 'decay', 0, ...
            'lengthScale_prior', plg, 'magnSigma2_prior', prior_fixed, ...
            'lengthScale_sexp_prior', prior_fixed, 'period_prior', prior_fixed);
        
        gpcf1 = gpcf_matern32('lengthScale', H(i,2:1+size(x1,2)), ...
            'magnSigma2', H(i,1),...
            'lengthScale_prior', plg, 'magnSigma2_prior', pms);
        
        gpcf2 = gpcf_periodic('lengthScale', H(i,end), ...
            'magnSigma2', 1, 'period', 1, 'lengthScale_sexp', 1, 'decay', 0, ...
            'lengthScale_prior', plg, 'magnSigma2_prior', prior_fixed, ...
            'lengthScale_sexp_prior', prior_fixed, 'period_prior', prior_fixed);
        
    elseif kernelCombo == 3 % (NN, periodic)
        
        gpcf1_v = gpcf_neuralnetwork('selectedVariables', [1:size(x,2)-1], ...
            'weightSigma2', 1./H(i,2:1+size(x1,2)), ...
            'biasSigma2', H(i,1),...
            'biasSigma2_prior', plg, 'weightSigma2_prior', pms);
        
        gpcf2_v = gpcf_periodic('selectedVariables', size(x,2), 'lengthScale', H(i,end), ...
            'magnSigma2', 1, 'period', 1, 'lengthScale_sexp', 1, 'decay', 0, ...
            'lengthScale_prior', plg, 'magnSigma2_prior', prior_fixed, ...
            'lengthScale_sexp_prior', prior_fixed, 'period_prior', prior_fixed);
        
        gpcf1 = gpcf_neuralnetwork('biasSigma2', H(i,1), ...
            'weightSigma2', 1./H(i,2:1+size(x1,2)),...
            'biasSigma2_prior', pms, 'weightSigma2_prior', plg);
        
        gpcf2 = gpcf_periodic('lengthScale', H(i,end), ...
            'magnSigma2', 1, 'period', 1, 'lengthScale_sexp', 1, 'decay', 0, ...
            'lengthScale_prior', plg, 'magnSigma2_prior', prior_fixed, ...
            'lengthScale_sexp_prior', prior_fixed, 'period_prior', prior_fixed);
        %
    elseif kernelCombo == 4 % (Matern 5/2, Matern 5/2)
        
        gpcf1_v = gpcf_matern52('selectedVariables', [1:size(x,2)-1], 'lengthScale', H(i,2:1+size(x1,2)), ...
            'magnSigma2', H(i,1),...
            'lengthScale_prior', plg, 'magnSigma2_prior', pms);
        
        gpcf2_v = gpcf_matern52('selectedVariables', size(x,2), 'lengthScale', H(i,end), ...
            'magnSigma2', 1, 'lengthScale_prior', plg, 'magnSigma2_prior', pms);
        
        gpcf1 = gpcf_matern52('lengthScale', H(i,2:1+size(x1,2)), ...
            'magnSigma2', H(i,1),...
            'lengthScale_prior', plg, 'magnSigma2_prior', pms);
        
        gpcf2 = gpcf_matern52('lengthScale', H(i,end), ...
            'magnSigma2', 1, 'lengthScale_prior', plg, 'magnSigma2_prior', pms);
        
    elseif kernelCombo == 5 % (RBF, Matern 5/2)
        
        gpcf1_v = gpcf_sexp('selectedVariables', [1:size(x,2)-1], 'lengthScale', H(i,2:1+size(x1,2)), ...
            'magnSigma2', H(i,1),...
            'lengthScale_prior', plg, 'magnSigma2_prior', pms);
        
        gpcf2_v = gpcf_matern52('selectedVariables', size(x,2), 'lengthScale', H(i,end), ...
            'magnSigma2', 1, 'lengthScale_prior', plg, 'magnSigma2_prior', pms);
        
        gpcf1 = gpcf_sexp('lengthScale', H(i,2:1+size(x1,2)), ...
            'magnSigma2', H(i,1),...
            'lengthScale_prior', plg, 'magnSigma2_prior', pms);
        
        gpcf2 = gpcf_matern52('lengthScale', H(i,end), ...
            'magnSigma2', 1, 'lengthScale_prior', plg, 'magnSigma2_prior', pms);
        %
    else % (RBF, Matern 3/2)
        
        gpcf1_v = gpcf_sexp('selectedVariables', [1:size(x,2)-1], 'lengthScale', H(i,2:1+size(x1,2)), ...
            'magnSigma2', H(i,1),...
            'lengthScale_prior', plg, 'magnSigma2_prior', pms);
        
        gpcf2_v = gpcf_matern32('selectedVariables', size(x,2), 'lengthScale', H(i,end), ...
            'magnSigma2', 1, 'lengthScale_prior', plg, 'magnSigma2_prior', pms);
        
        gpcf1 = gpcf_sexp('lengthScale', H(i,2:1+size(x1,2)), ...
            'magnSigma2', H(i,1),...
            'lengthScale_prior', plg, 'magnSigma2_prior', pms);
        
        gpcf2 = gpcf_matern32('lengthScale', H(i,end), ...
            'magnSigma2', 1, 'lengthScale_prior', plg, 'magnSigma2_prior', pms);
        %
    end
    
    gpcf = gpcf_prod('cf', {gpcf1_v, gpcf2_v}); % product of gpcf1 and gpcf2
    
    % Create the GP structure
    % if one noise only, jitter for gp is what matters only (jitter for gp1 and gp2 neither used, nor needed)
    % if two noises, jitter for gp1 and for gp2 is what matters only (jitter for gp neither used, nor needed)
    
    gp_all{i} = gp_set('lik', lik, 'cf', gpcf, 'jitterSigma2', jitter);
    
    gp1_all{i} = gp_set('lik', lik, 'cf', gpcf1, 'jitterSigma2', jitter);
    gp2_all{i} = gp_set('lik', lik, 'cf', gpcf2, 'jitterSigma2', jitter);
    
    % Set the options for the optimization
    opt=optimset('TolFun',1e-6,'TolX',1e-6, 'MaxFunEvals',2000); %
    
    % Optimise
    [gp_all{i}, nlml(i)] = gp_optim(gp_all{i},x,y,gp1_all{i}, gp2_all{i}, x1, x2, 'opt',opt); %mpaun inserted this
    
end

I = find(nlml == min(nlml));
gp = gp_all{I};
gp1 = gp1_all{I};
gp2 = gp2_all{I};

disp('done')

% update gp1 and gp2 too after gp hyperparameter update
%     gp1.lik.sigma2 = gp_all{I}.lik.sigma2; %zero
%     gp2.lik.sigma2 = gp_all{I}.lik.sigma2; %zero
%
%     gp1.cf{1}.magnSigma2 = gp_all{I}.cf{1,1}.cf{1}.magnSigma2;
%     gp2.cf{1}.magnSigma2 = gp_all{I}.cf{1,1}.cf{2}.magnSigma2;
%
%     gp1.cf{1}.lengthScale = gp_all{I}.cf{1,1}.cf{1}.lengthScale;
%     gp2.cf{1}.lengthScale = gp_all{I}.cf{1,1}.cf{2}.lengthScale;

%or (neater)
[w,s] = gp_pak(gp_all{I});
%update gp1 and gp2 hyperparameters too
gp1 = gp_unpak(gp1, w(1:(1+size(x1,2)))); % one magnitude s2 and nd lengthscales (for the parameters)
gp2 = gp_unpak(gp2, w((2+size(x1,2):end))); % 1 lengthscale (for time)

end

