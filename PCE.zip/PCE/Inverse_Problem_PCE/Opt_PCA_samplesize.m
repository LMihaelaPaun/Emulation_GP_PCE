clear; close all;
%%
for which_model = 1:2 % WK 1, ST 2
    number_of_samples = [100 1000];
    for samp_id = 1:length(number_of_samples)

        if which_model==1
            if samp_id == 1
                pce_deg = 3;
            else
                pce_deg = 6;
            end
            load ../Data_Files/WK_5par_PCA.mat
            load ../Data_Files/WK_5par_test.mat p_test
            fname = strcat('invprob_WK_PCA_sqp_n',num2str(number_of_samples(samp_id)), ...
                '_deg',num2str(pce_deg));
            loadname = strcat('../Plot_Figures/Figure3/WK_PCA_sqp_n',num2str(number_of_samples(samp_id)), ...
                '_deg',num2str(pce_deg),'_PCE');
            load(loadname)
            l = [30000 -30 0.05 0.05 0.05];
            u = [200000 -10 3   3     3];
        else
            if samp_id == 1
                pce_deg = 4;
            else
                pce_deg = 6;
            end
            load ../Data_Files/ST_4par_PCA.mat
            load ../Data_Files/ST_4par_test.mat p_test
            fname = strcat('invprob_ST_PCA_sqp_n',num2str(number_of_samples(samp_id)), ...
                '_deg',num2str(pce_deg));

            loadname = strcat('../Plot_Figures/Figure3/ST_PCA_sqp_n',num2str(number_of_samples(samp_id)), ...
                '_deg',num2str(pce_deg),'_PCE');
            load(loadname)
            l = [80000 -30 0.80 3];
            u = [200000 -5 0.92 10];
        end
        pca_coeff = PCE_coeff;
        pca_mu    = mu;
        %%
        p_test   = p_test(1:8:end,:)';
        par_test = x_PCA_test;
        ntp = size(p_test,2);

        %% Parameters
        par_sgn = sign(l);

        l_sc = l./sc;
        u_sc = u./sc;

        num_par = length(l);
        nd = num_par;

        n_samp = 20;
        par_storage = zeros(100,nd,n_samp);
        J_storage   = zeros(100,n_samp);
        para_init = zeros(100,nd,n_samp);
        %%
        %     parpool(6);
        for which_data = 1:100

            par_true = par_test(which_data,:);

            %% Data
            % here load your clean (noise-free) data
            truePressure = p_test(which_data,:);
            Fopt = @(q) objective_function_PCA(q, truePressure,myPCE,sc,[],pca_mu,pca_coeff);

            % Choose randomized initial conditions
            opts = optimoptions('fmincon','Display','off','Algorithm','sqp',...
                'StepTolerance',  1.0000e-6, 'OptimalityTolerance', 1.0000e-6, ...
                'ConstraintTolerance', 1.0000e-6, 'FiniteDifferenceType', 'central');

            for i=1:n_samp
                disp([which_data i]);
                par0 = unifrnd(l_sc,u_sc,1,num_par);
                [X,FVAL,EXITFLAG,OUTPUT,LAMBDA,GRAD,HESSIAN] = ...
                    fmincon(Fopt,par0,[],[],[],[],l_sc,u_sc,[],opts);

                para_init(which_data,:,i)   = par0.*sc;
                par_storage(which_data,:,i) = X.*sc;
                J_storage(which_data,i)     = FVAL;
            end

        end
        save(fname,'para_init','par_storage','J_storage','myPCE','opts')
    end
end