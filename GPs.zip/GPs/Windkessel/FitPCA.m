clear

% add path to the original GPstuff toolbox (without the changes made to
% accommodate kronecker product for multioutput GP)
addpath(genpath('/GPstuff-4.7'))

addpath('/CommonFunctions')

noPar = 5; % 4, 5, 6

% load the training data
if noPar==4
    load('WK_4par_train.mat')
elseif noPar==5
    load('WK_5par_train_new.mat')
else
    load('WK_6par_train.mat')
end

nd = size(par_train,2);

n_train = size(par_train,1); % no of training points
x_train = par_train(1:n_train,:); % take a subset of all training points

% The order is [f1,f2,r1,r2,c]
l = [3e4 -30 0.05 0.05 0.05];
u = [2e5 -5 3 3 3];

sc = max(abs(l),abs(u));

x_train = x_train./sc;

pressures_train=(p_train(:,1:n_train))';

pressures_train = pressures_train(:,1:8:end); % take every 8th point

ntp=size(pressures_train,2); % no of time points

% PCA data (take the same as training data)
n_PCA = n_train; % no of training points
x_PCA = x_train; % this is already scaled

% take the corresponding subset of pressures; only MPA pressure
pressures_PCA = pressures_train;

% GP or PCA testing data
if noPar==4
    load('WK_4par_test.mat')
elseif noPar==5
    load('WK_5par_test.mat')
else
    load('WK_6par_test.mat')
end

n_test = size(par_test,1);
x_test = par_test;

x_test = x_test./sc;

pressures_test=p_test';

pressures_test = pressures_test(:,1:8:end); % take every 8th point

% fit PCA on data
[coeff,score,latent,tsquared,explained,mu] = pca(pressures_PCA);

meanMSE_PCA_train = NaN(min(size(coeff,2),20),1);

for NC = 1:(min(size(coeff,2),20))
    pressures_recons = score(:,1:NC)*coeff(:,1:NC)'+mu;
    
    MSE_PCA_train = sum((pressures_PCA - pressures_recons).^2,2);
    
    meanMSE_PCA_train(NC) = mean(MSE_PCA_train, "omitnan"); % !!! quantity of interest
end

% test PCA on test data
meanMSE_PCA_test = NaN(min(size(coeff,2),20),1);

for NC = 1:(min(size(coeff,2),20))
    PCscores_test = (pressures_test - mu)*coeff(:, 1:NC); % using only the first NC PCs
    
    pressures_test_PCA_recons = PCscores_test * coeff(:,1:NC)' + mu;
    
    MSE_PCA_test = sum((pressures_test- pressures_test_PCA_recons).^2,2);
    
    meanMSE_PCA_test(NC) = mean(MSE_PCA_test, "omitnan"); % !!! quantity of interest
end
    
% figure;plot(meanMSE_PCA_train,'.');hold on;plot(meanMSE_PCA_test,'.')

NC = 5; % choose 5 PCs

PCscores_test = (pressures_test - mu)*coeff(:, 1:NC); % using only the first NC PCs

pressures_test_PCA_recons = PCscores_test * coeff(:,1:NC)' + mu;

figure(1);clf(1)
for i=61:70%n_test
    subplot(2,5,i-60);hold on
    plot(linspace(0,0.11,ntp),pressures_test(i,:), '-','linewidth', 3)
    plot(linspace(0,0.11,ntp),pressures_test_PCA_recons(i,:), '--','linewidth', 3)
end
legend('Original', 'Reconstructed')
title(sprintf('%d PCs', NC))

save(sprintf('PCAresults_WK_noPar %d.mat', noPar))