function OptimHistory = GradientAlgorithm(param0, truePressure, extra_p)

EmulationApproach = extra_p{1};

if EmulationApproach == 1 % emulate whole signal
    
    gp = extra_p{2};
    x_regr = extra_p{3};
    output = extra_p{4};
    gp1 = extra_p{5};
    gp2 = extra_p{6};
    x1 = extra_p{7};
    x2 = extra_p{8};
    mean_y = extra_p{9};
    std_y = extra_p{10};
    ntp = extra_p{11};
    nd = extra_p{12};
    l = extra_p{13};
    u = extra_p{14};
    sc = extra_p{15};
    
else % emulate PCs
    
    gp = extra_p{2};
    x_regr = extra_p{3};
    y = extra_p{4};
    NC = extra_p{5};
    coeff = extra_p{6};
    mu = extra_p{7};
    mean_y = extra_p{8};
    std_y = extra_p{9};
    ntp = extra_p{10};
    nd = extra_p{11};
    l = extra_p{12};
    u = extra_p{13};
    sc = extra_p{14};
end

% Set up shared variables with OUTFUN
OptimHistory.x = [];
OptimHistory.fval = [];

%% Contrained optimization with gradient based method (sqp algorithm)
options=optimoptions('fmincon', 'Display','iter', 'Algorithm','sqp', ...
    'OutputFcn',@outfun, ...
    'StepTolerance',  1.0000e-6, 'OptimalityTolerance', 1.0000e-6, ...
    'ConstraintTolerance', 1.0000e-6, 'FiniteDifferenceType', 'central');

[x,fval] = fmincon(@(x)GetObjFct(x), ...
    param0, [], [], [], [], l./sc, u./sc, [], options);


    function stop = outfun(x,optimValues,state)
        
        stop = false;
        
        switch state
            case 'init'
                hold on
            case 'iter'
                % Concatenate current point and objective function value with history
                % x must be a row vector
                OptimHistory.fval = [OptimHistory.fval; optimValues.fval];
                OptimHistory.x = [OptimHistory.x; x];
                
                %save(sprintf('historySQPoptimisation %d.mat',irun)) % save the progress so far
                
            case 'done'
                hold off
            otherwise
        end
        
    end

    function ObjFct = GetObjFct(param)
        % Get objective function
    
        if EmulationApproach == 1 % emulate whole signal
            
            GPpath_multioutput = genpath('/gpstuff-develop');
            addpath(GPpath_multioutput)
    
            input_test = NaN(ntp,nd+1);
            count=0;
            for j=1:ntp
                count=count+1;
                input_test(count,:) = [param x2(j)];
            end
            
            E_test_multiOutput = gp_pred(gp, x_regr, output, gp1, gp2, x1, x2, input_test);
            
            pressure = E_test_multiOutput.*std_y+mean_y;
            
            rmpath( GPpath_multioutput )
            
        else % emulate PCs
            
            GPpath_unioutput = genpath('/GPstuff-4.7');
            addpath(GPpath_unioutput)
            
            E = NaN(1,NC);
            
            for i=1:NC
                % Make predictions of every PC score using gp models
                E(i) = gp_pred(gp{i}, x_regr, y(:,i), param);
            end
            
            pressure = (E.*std_y+mean_y) * coeff(:,1:NC)' + mu;
            
            pressure = pressure';
            
            rmpath( GPpath_unioutput )
            
        end
        
        ObjFct = sum((pressure-truePressure).^2); % minimise RSS
        
        
    end

end

