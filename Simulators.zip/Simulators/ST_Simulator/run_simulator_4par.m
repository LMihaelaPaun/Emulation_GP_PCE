%% Run the 1D model with the parameter estimates from the emulator
clc; clear all; %close all;
%% Define scaling factors for resistance/compliance if needed
% Four parameter set: assumes that k3 = 0, and k1 and k2 are the same in
% both the large arteries and small arteries. Alpha for the structured tree
% is a free variable, while beta is fixed at 0.66, as well as the minimum
% radius, rmin=0.005
k1 = 1e5;
k2 = -20;
k3 = 0;
alpha = 0.88;
beta = 0.66;
lrr = 5;
rmin = 0.005;
Zterm = 0.0;
vaso = 1.0;

pars = [k1 k2 k3 ...
        k1 k2 k3 ...
        alpha beta lrr rmin Zterm vaso 1];
pars_str = mat2str(pars);
%% call the model

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
unix(sprintf('sor06.exe  %s',pars_str(2:end-1)));
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Plotting Simulated data
% Plot inlet/outlet waveforms in the whole tree
fname_load = strcat('pu_ALL_',num2str(1),'.2d');
data = load(fname_load);
% data = dlmread('art_ALL.2d');
[~,~,p,~,~,~] = gnuplot(data);
delete(fname_load);

figure; plot(p);





