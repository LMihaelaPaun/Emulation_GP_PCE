% Plot the emulation error for the forward problem
% Use the worst solutions in the parameter space
clear; clc; close all;
y_min1 = -13;
y_max1 = 10;
y_min2 = -16;
y_max2 = 10;
f = @(q,q_true) sum(((q-q_true)./q_true).^2,2);
figure(2); tiledlayout(4, 4, "TileSpacing", "compact"); 
%% 
load ../Data_Files/ST_4par_test.mat
p_test = p_test(1:8:end,:);
%% ST - time, 100
load ST_Time_sqp_n100_deg4_PCE.mat myPCE
load ST_Time_sqp_n100_deg4.mat

par_best = par_best_J;
Y_em  = uq_evalModel(myPCE,par_best);
Y_sim = cell2mat(p_simulator');
Y_sim = Y_sim(1:8:end,2:3:end)';

MSE_em_T_ST_n100 = sum((Y_em-p_test').^2,2)./32;
MSE_sim_T_ST_n100 = sum((Y_sim-p_test').^2,2)./32;
par_err_T_ST_n100 = f(par_best,par_test);

[~,id_worst] = max(par_err_T_ST_n100);
nexttile(1); hold on;
plot(p_test(:,id_worst),'k','LineWidth',2); plot(Y_sim(id_worst,:),'-.r','LineWidth',2);
set(gca,'FontSize',20); grid on;
title('PCE.time.100')


%% ST - PCA, 100
load ../Data_Files/ST_4par_PCA.mat

load ST_PCA_sqp_n100_deg4_PCE.mat myPCE
load ST_PCA_sqp_n100_deg4.mat
par_best = par_best_J;
Y_em = uq_evalModel(myPCE,par_best./sc)*PCE_coeff' + mu;
Y_sim = cell2mat(p_simulator');
Y_sim = Y_sim(1:8:end,2:3:end)';

MSE_em_PCA_ST_n100 = sum((Y_em-p_test').^2,2)./32;
MSE_sim_PCA_ST_n100 = sum((Y_sim-p_test').^2,2)./32;
par_err_PCA_ST_n100 = f(par_best,par_test);

[~,id_worst] = max(par_err_PCA_ST_n100);
figure(2); nexttile(5); hold on;
plot(p_test(:,id_worst),'k','LineWidth',2); plot(Y_sim(id_worst,:),'-.r','LineWidth',2);
set(gca,'FontSize',20); grid on;
title('PCE.PCA.100')

%% ST - time, 1000
load ../Data_Files/ST_4par_test.mat
p_test = p_test(1:8:end,:);

load ST_Time_sqp_n1000_deg6_PCE.mat myPCE
load ST_Time_sqp_n1000_deg6.mat
par_best = par_best_J;
Y_em  = uq_evalModel(myPCE,par_best);
Y_sim = cell2mat(p_simulator');
Y_sim = Y_sim(1:8:end,2:3:end)';

MSE_em_T_ST_n1000 = sum((Y_em-p_test').^2,2)./32;
MSE_sim_T_ST_n1000 = sum((Y_sim-p_test').^2,2)./32;
par_err_T_ST_n1000 = f(par_best,par_test);

[~,id_worst] = max(par_err_T_ST_n1000);
figure(2); nexttile(9); hold on;
plot(p_test(:,id_worst),'k','LineWidth',2); plot(Y_sim(id_worst,:),'-.r','LineWidth',2);
set(gca,'FontSize',20); grid on;
title('PCE.time.1000')

%% ST - PCA, 1000
load ../Data_Files/ST_4par_PCA.mat

load ST_PCA_sqp_n1000_deg6_PCE.mat myPCE
load ST_PCA_sqp_n1000_deg6.mat
par_best = par_best_J;
Y_em = uq_evalModel(myPCE,par_best./sc)*PCE_coeff' + mu;
Y_sim = cell2mat(p_simulator');
Y_sim = Y_sim(1:8:end,2:3:end)';

MSE_em_PCA_ST_n1000 = sum((Y_em-p_test').^2,2)./32;
MSE_sim_PCA_ST_n1000 = sum((Y_sim-p_test').^2,2)./32;
par_err_PCA_ST_n1000 = f(par_best,par_test);

[~,id_worst] = max(par_err_PCA_ST_n1000);
figure(2); nexttile(13); hold on;
plot(p_test(:,id_worst),'k','LineWidth',2); plot(Y_sim(id_worst,:),'-.r','LineWidth',2);
set(gca,'FontSize',20); grid on;
title('PCE.PCA.1000')
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% WK - time, 100
load ../Data_Files/WK_5par_test.mat
p_test = p_test(1:8:end,:);

load WK_Time_sqp_n100_deg3_PCE.mat myPCE
load WK_Time_sqp_n100_deg3.mat
par_best = par_best_J;
Y_em  = uq_evalModel(myPCE,par_best);
Y_sim = cell2mat(p_simulator');
Y_sim = Y_sim(1:8:end,2:3:end)';

MSE_em_T_WK_n100 = sum((Y_em-p_test').^2,2)./32;
MSE_sim_T_WK_n100 = sum((Y_sim-p_test').^2,2)./32;
par_err_T_WK_n100 = f(par_best,par_test);

[~,id_worst] = max(par_err_T_WK_n100);
figure(2); nexttile(3); hold on;
plot(p_test(:,id_worst),'k','LineWidth',2); plot(Y_sim(id_worst,:),'-.r','LineWidth',2);
set(gca,'FontSize',20); grid on;
title('PCE.time.100')

%% WK - PCA, 100
load ../Data_Files/WK_5par_PCA.mat

load WK_PCA_sqp_n100_deg3_PCE.mat myPCE
load WK_PCA_sqp_n100_deg3.mat
par_best = par_best_J;
Y_em = uq_evalModel(myPCE,par_best./sc)*PCE_coeff' + mu;
Y_sim = cell2mat(p_simulator');
Y_sim = Y_sim(1:8:end,2:3:end)';

MSE_em_PCA_WK_n100 = sum((Y_em-p_test').^2,2)./32;
MSE_sim_PCA_WK_n100 = sum((Y_sim-p_test').^2,2)./32;
par_err_PCA_WK_n100 = f(par_best,par_test);

[~,id_worst] = max(par_err_PCA_WK_n100);
figure(2); nexttile(7); hold on;
plot(p_test(:,id_worst),'k','LineWidth',2); plot(Y_sim(id_worst,:),'-.r','LineWidth',2);
set(gca,'FontSize',20); grid on;
title('PCE.PCA.100')

%% WK - time, 1000
load ../Data_Files/WK_5par_test.mat
p_test = p_test(1:8:end,:);

load WK_Time_sqp_n1000_deg6_PCE.mat myPCE
load WK_Time_sqp_n1000_deg6.mat
par_best = par_best_J;
Y_em  = uq_evalModel(myPCE,par_best);
Y_sim = cell2mat(p_simulator');
Y_sim = Y_sim(1:8:end,2:3:end)';

MSE_em_T_WK_n1000 = sum((Y_em-p_test').^2,2)./32;
MSE_sim_T_WK_n1000 = sum((Y_sim-p_test').^2,2)./32;
par_err_T_WK_n1000 = f(par_best,par_test);

[~,id_worst] = max(par_err_T_WK_n1000);
figure(2); nexttile(11); hold on;
plot(p_test(:,id_worst),'k','LineWidth',2); plot(Y_sim(id_worst,:),'-.r','LineWidth',2);
set(gca,'FontSize',20); grid on;
title('PCE.time.1000')

%% WK - PCA, 1000
load ../Data_Files/WK_5par_PCA.mat

load WK_PCA_sqp_n1000_deg6_PCE.mat myPCE
load WK_PCA_sqp_n1000_deg6.mat
par_best = par_best_J;
Y_em = uq_evalModel(myPCE,par_best./sc)*PCE_coeff' + mu;
Y_sim = cell2mat(p_simulator');
Y_sim = Y_sim(1:8:end,2:3:end)';

MSE_em_PCA_WK_n1000 = sum((Y_em-p_test').^2,2)./32;
MSE_sim_PCA_WK_n1000 = sum((Y_sim-p_test').^2,2)./32;
par_err_PCA_WK_n1000 = f(par_best,par_test);

[~,id_worst] = max(par_err_PCA_WK_n1000);
figure(2); nexttile(15); hold on;
plot(p_test(:,id_worst),'k','LineWidth',2); plot(Y_sim(id_worst,:),'-.r','LineWidth',2);
set(gca,'FontSize',20); grid on;
title('PCE.time.1000')


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%5
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%% GPs %%%%%%%%%%%%%%%%%%%%%%%%
%%
load('Mitchel_GP_time_WorstSignalPredictions_ST.mat','worstPressure','WorstInferenceDataIndex_multi','p_test')
nexttile(2);
plot(p_test(1:8:end,WorstInferenceDataIndex_multi(1)),'-k','LineWidth',2);
hold on;
plot(worstPressure(1,:),'-.r','LineWidth',2);
set(gca,'FontSize',20); grid on;
title('GP.time.100')
nexttile(10);
plot(p_test(1:8:end,WorstInferenceDataIndex_multi(2)),'-k','LineWidth',2);
hold on;
plot(worstPressure(2,:),'-.r','LineWidth',2);
set(gca,'FontSize',20); grid on;
title('GP.time.1000')


load('Mitchel_GP_PCA_WorstSignalPredictions_ST.mat','worstPressure','WorstInferenceDataIndex_PCA','p_test')
nexttile(6);
plot(p_test(1:8:end,WorstInferenceDataIndex_PCA(1)),'-k','LineWidth',2);
hold on;
plot(worstPressure(1,:),'-.r','LineWidth',2);
set(gca,'FontSize',20); grid on;
title('GP.PCA.100')
nexttile(14);
plot(p_test(1:8:end,WorstInferenceDataIndex_PCA(2)),'-k','LineWidth',2);
hold on;
plot(worstPressure(2,:),'-.r','LineWidth',2);
set(gca,'FontSize',20); grid on;
title('GP.PCA.1000')

%%
load('Mitchel_GP_time_WorstSignalPredictions_WK.mat','worstPressure','WorstInferenceDataIndex_multi','p_test')
nexttile(4);
plot(p_test(1:8:end,WorstInferenceDataIndex_multi(1)),'-k','LineWidth',2);
hold on;
plot(worstPressure(1,:),'-.r','LineWidth',2);
set(gca,'FontSize',20); grid on;
title('GP.time.100')
nexttile(12);
plot(p_test(1:8:end,WorstInferenceDataIndex_multi(2)),'-k','LineWidth',2);
hold on;
plot(worstPressure(2,:),'-.r','LineWidth',2);
set(gca,'FontSize',20); grid on;
title('GP.time.1000')


load('Mitchel_GP_PCA_WorstSignalPredictions_WK.mat','worstPressure','WorstInferenceDataIndex_PCA','p_test')
nexttile(8);
plot(p_test(1:8:end,WorstInferenceDataIndex_PCA(1)),'-k','LineWidth',2);
hold on;
plot(worstPressure(1,:),'-.r','LineWidth',2);
set(gca,'FontSize',20); grid on;
title('GP.PCA.100')
nexttile(16);
plot(p_test(1:8:end,WorstInferenceDataIndex_PCA(2)),'-k','LineWidth',2);
hold on;
plot(worstPressure(2,:),'-.r','LineWidth',2);
set(gca,'FontSize',20); grid on;
title('GP.PCA.1000')
%%
% ha = annotation('textbox',[0.26 0.89 0.1 0.1],'string','     ST     ','FontSize',20,'FitBoxToText','on');
% ha.HorizontalAlignment = 'center';
% 
% hb = annotation('textbox',[0.68 0.89 0.1 0.1],'string','     WK     ','FontSize',20,'FitBoxToText','on');
% hb.HorizontalAlignment = 'center';
for i=1:16
    nexttile(i); xticks([1 16 32]); xticklabels({'0','0.05','0.11'})
end
for i = [13:16]
   xlabel('Time (s)');
end