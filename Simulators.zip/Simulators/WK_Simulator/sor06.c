/***************************************************************************/
/*                                                                         */
/* The sor06.C main program                                                */
/*  Version: 1.0                                                           */
/*  Date: 30 Dec. 2019                                                     */
/*                                                                         */
/*  Primary Authors: M.S. Olufsen                                          */
/*  Key Contributers: M.U. Qureshi & M.J. Colebank                         */
/*  Institute: North Carolina State University, Raleigh, NC, USA           */
/*  Funded by: NSF-DMS # 1615820 & AHA #19PRE34380459                      */
/*                                                                         */
/***************************************************************************/

#include "sor06.h"
#include "tools.h"
#include "arteries.h"
#include "junction.h"

#include <cstdio>
#include <cstdlib>
#include <cmath>
#include <ctime>
#include <cstring>

using namespace std;

// The vessel-network is specified and initialized, and the flow and
// pressures are to be determed. All global constants must be defined
// in the header file. That is the number of dots per cm, and the number
// of vessels.
int main(int argc, char *argv[])
{
    double tstart, tend, finaltime;
    // Declare stiffness parameters
    double f1, f2, f3;
    double r1_scale, r2_scale, c_scale;
    // Declare the parameters describing the network size
    int total_vessels, total_terminal, total_conn,number_of_points;
    int total_sten; // Number of stenoses
    fflush(stdout);
    //==========adjustment in resistances (WK parameters) for the control========
    
    
    if (argc != 8) //argv[0] is the name of the program, here sor06
    {
        printf("Not enough input arguments: only %d. Exiting. \n", argc);
        return 1;
    }
    
    f1   = atof(argv[1]);
    f2   = atof(argv[2]);
    f3   = atof(argv[3]);
    
    r1_scale = atof(argv[4]); //Scales the proximal resistance for a 3-WK
    r2_scale = atof(argv[5]); //Scales the distal resistance for a 3-WK
    c_scale  = atof(argv[6]); //Scales the total compliance for a 3-WK
    
    
    total_vessels    = 21;
    total_terminal   = 11;
    number_of_points = 40;

    total_sten = 0;

    int vessel_id = atoi(argv[7]);
    
    total_conn         = total_vessels-total_terminal;
    nbrves             = total_vessels;
    
    // fprintf(stdout,"On iteration %d.\n",vessel_id);
//     printf("f1 f2 f3 Tper: %lf %lf %lf %lf,\n vessels, terminal, numpts: %d, %d, %d\n",f1, f2, f3, Tper, total_vessels, total_terminal, number_of_points);
        
//     printf("sten out %d \n",total_sten);
    /* Declare string vectors and files to hold 
     * the output from the model. This can 
     * be expanded to have more vessels
     */
    
    char namepuALL[20];
    sprintf(namepuALL, "pu_ALL_%d.2d", vessel_id);
    
    FILE *fpALL = fopen (namepuALL, "w");
  
    
    // Workspace used by bound_bif
    for(int i=0; i<24; i++) fjac[i] = new double[24];
    tstart    = 0.0;            // Starting time.
    
    // The number of vessels in the network is given when the governing array of
    // vessels is declared.
    
// =========================NETWORK =================================================================================
    
    Tube   *Arteries[nbrves];                     // Array of blood vessels.
    int connectivity_matrix[total_vessels][max_D];// Matrix with vessels
    double bc_matrix[total_terminal][3];          // WK bound. matrix
    int terminal_vessels[total_terminal];         // ID's for term. ves.
    double dimensions_matrix[total_vessels][3];   // Length and radius
    FILE *conn;
    conn = fopen("connectivity.txt","rt");
    int parent, daughter1, daughter2, daughter3, r_in;
    int conn_id = 0;
    
    
    // Check to see if we have the connectivity file
   if (conn == NULL)
   {
       fprintf(stdout,"Error: Connectivity File Does Not Exist \n");
       return 1;
   }
    while ((r_in = fscanf(conn, "%d %d %d %d", &parent, &daughter1, &daughter2, &daughter3)) != EOF)
    {
        connectivity_matrix[conn_id][0] = parent;
        connectivity_matrix[conn_id][1] = daughter1;
        connectivity_matrix[conn_id][2] = daughter2;
        connectivity_matrix[conn_id][3] = daughter3;
        conn_id++;
    }
    fclose(conn);
    
    
       /////////////// Load in the 3-WK Boundary Conditions Matrix
    FILE *BCs;
    BCs = fopen("Windkessel_Parameters.txt","rt");
   if (BCs==NULL)
   {
       fprintf(stdout,"Error: Boundary Conditions File Does Not Exist");
       return 1;
   }
    for (int i=0; i<total_terminal; i++){
        fscanf(BCs, "%lf %lf %lf",&bc_matrix[i][0],&bc_matrix[i][1],&bc_matrix[i][2]);
        
        // Scaling factors
        bc_matrix[i][0] *= r1_scale;
        bc_matrix[i][1] *= r2_scale;
        bc_matrix[i][2] *= c_scale;
    }
    
    fclose(BCs);

    /////////////// Load in stenosed vessels & percent stenosis
    FILE *sten_file;
    sten_file = fopen("Sten.txt","rt");
    double sten_ves[total_sten][3];
    for (int i = 0;i < total_sten; i++){
        fscanf(sten_file, "%lf %lf %lf", &sten_ves[i][0],&sten_ves[i][1],&sten_ves[i][2]);
       fprintf(stdout,"i: %d STEN:%lf SEVERITY:%lf LENGTH: %lf\n",i,sten_ves[i][0],sten_ves[i][1],sten_ves[i][2]);
    }
    fclose(sten_file);
    

    /////////////// Load in terminal vessels
            
    FILE *terminal_file;
    terminal_file = fopen("terminal_vessels.txt","rt");
    for (int i=0; i<total_terminal; i++){
        fscanf(terminal_file, "%d", &terminal_vessels[i]);
    }
    fclose(terminal_file);
    
    
    /////////////// Load in Dimensions

    FILE *dim_file;
    dim_file = fopen("Dimensions.txt","rt");
    for (int dim_ID = 0; dim_ID < total_vessels; dim_ID++){
        fscanf(dim_file, "%5lf %5lf %5lf", &dimensions_matrix[dim_ID][0],&dimensions_matrix[dim_ID][1],&dimensions_matrix[dim_ID][2]);
    }
    fclose(dim_file);
    /* Initialization of the Arteries.
    // The tube class takes in the following values (in this order)
         Length: the length of the artery
     
         Top radius: the radius at the entry of the vessel
     
         Bottom radius: the radius at the end of the vessel
     
         Daughter Pointer: the pointer to the connectivity of all the blood
                           vessels, passed to junction.c
          
         Num Points: the number of pts (per non-dimensional length) to use in numerical solution
     
         Init: Set to 1 to make this vessel the inlet vessel (i.e., it gets a flow prescribed); set 0 else
     
         f1,f2,f3: Stiffness in the large blood vessels (Eh/r0 = f1*exp(f2*r0)+f3)
     
         R1,R2,CT: the proximal and distal resistance parameters and the peripheral compliance, used in the windkessel boundary condition
     
        */
    double R1, R2, CT;
    int term_id = total_terminal-1;
    int bc_id = total_terminal-1;
    int sten_id = total_sten-1;
    conn_id = total_conn-1;    
    // MJC: For trying to pass junction condition around
    int *daughter_ptr = &connectivity_matrix[0][0];
    if (total_vessels == 1){
         R1 = bc_matrix[0][0];
        R2 = bc_matrix[0][1];
        CT = bc_matrix[0][2];
        if (total_sten>0){
            fprintf(stdout,"STEN BIF\n");
            Arteries[0] = new Tube( dimensions_matrix[0][0]-sten_ves[0][2], dimensions_matrix[0][1], dimensions_matrix[0][2],
                                    daughter_ptr, number_of_points, 1,f1,f2,f3, R1, R2, CT, sten_ves[0][1],sten_ves[0][2]);
            sten_id--;
        }
        else{
       printf("R1 R2 C:  %lf %lf %lf\n",R1,R2,CT);
        Arteries[0] = new Tube( dimensions_matrix[0][0], dimensions_matrix[0][1], dimensions_matrix[0][2], 
                                daughter_ptr, number_of_points, 1,f1,f2,f3, R1, R2, CT, 0, 0);
    }
    }

    else if (total_vessels > 1){
        // NOTE: In order to set up the tube class, vessels must be initilized
        // starting from the most terminal vessel (the vessel with the largest
        // ID number), and then works back to the root vessel in the network.
        for (int i=total_vessels-1; i>=0; i--) {
            //first vessels
            if (i==0) {
//                fprintf(stdout,"At inlet: %d\n",i);
               fflush(stdout);
               if (total_sten>0 && i==sten_ves[sten_id][0]){
                    fprintf(stdout,"STEN BIF\n");
                    Arteries[0] = new Tube( dimensions_matrix[i][0]-sten_ves[sten_id][2], dimensions_matrix[i][1], dimensions_matrix[i][2],
                                    daughter_ptr, number_of_points, 1,f1,f2,f3, 0,0,0, sten_ves[sten_id][1],sten_ves[sten_id][2]);
                    sten_id--;
                }
                else {
                    Arteries[i] = new Tube( dimensions_matrix[i][0], dimensions_matrix[i][1], dimensions_matrix[i][2], daughter_ptr, number_of_points, 1, f1,f2,f3, 0, 0, 0, 0, 0);
                }
            }
            else{
                if (i == terminal_vessels[term_id] && term_id>=0){
                    R1 = bc_matrix[bc_id][0];
                    R2 = bc_matrix[bc_id][1];
                    CT = bc_matrix[bc_id][2];
                    
//                    fprintf(stdout,"At terminal & BCid: %d %d \n",i,bc_id);
                   if (total_sten>0 && i==sten_ves[sten_id][0]){
                    fprintf(stdout,"STEN BIF\n");
                    Arteries[i] = new Tube( dimensions_matrix[i][0]-sten_ves[sten_id][2], dimensions_matrix[i][1], dimensions_matrix[i][2],
                                            daughter_ptr, number_of_points, 0,f1,f2,f3, R1, R2, CT, sten_ves[sten_id][1],sten_ves[sten_id][2]);
                    sten_id--;
                  }
                   else{
                    Arteries[i] = new Tube( dimensions_matrix[i][0], dimensions_matrix[i][1], dimensions_matrix[i][2], daughter_ptr, number_of_points, 0, f1,f2,f3, R1, R2, CT, 0,0);
                   }
                    term_id--;
                    bc_id--;
                }
                else
                {
//                    fprintf(stdout,"At interior: %d\n",i);
                   if (total_sten>0 && i==sten_ves[sten_id][0]){
                    fprintf(stdout,"STEN BIF\n");
                    Arteries[i] = new Tube( dimensions_matrix[i][0]-sten_ves[sten_id][2], dimensions_matrix[i][1], dimensions_matrix[i][2],
                                            daughter_ptr, number_of_points, 0,f1,f2,f3, 0,0,0, sten_ves[sten_id][1],sten_ves[sten_id][2]);
                    sten_id--;
                  }
                   else{
                    Arteries[i] = new Tube( dimensions_matrix[i][0], dimensions_matrix[i][1], dimensions_matrix[i][2], daughter_ptr, number_of_points, 0, f1,f2,f3, 0, 0, 0, 0, 0);
                   }
                }
            }
        }
    }

    
    // Solves the equations until time equals tend.///////////////////////////
    /* ADDED BY M. J. Colebank
     * Rather than specifying the number of cycles as an input to the function,
     * we want to test to see if the solution has converged. If so, we should exit.*/
    
    int period_counter = 1; // Count the number of periods you have solved for
    double norm_sol = 1e+6;
    double sol_tol  = 1e-5;
//     fflush(stdout);
//     printf("NORM_SOL: %f\n",norm_sol);
    double sol_p1[tmstps],sol_p2[tmstps];
    tend      = Deltat;
    
    
    // Solve the model once for initial convergence diagnostics
    int sol_ID = 0;
    while (tend<=period_counter*Period)
    {
    solver (Arteries, tstart, tend, k, Period, WALL_MODEL, VEL_MODEL);
    sol_p1[sol_ID] = Arteries[0]->P(0,Arteries[0]->Anew[0], WALL_MODEL);
    sol_p1[sol_ID] *= rho*g*Lr/conv;
    tstart = tend;
    tend   = tend + Deltat; // The current ending time is increased by Deltat.
    sol_ID++;
    }
    
    
    // Loop for convergence
    double sse;
    while (norm_sol>=sol_tol)
    {
        sol_ID = 0;
        sse    = 0;
        period_counter++;
        if (period_counter>max_cycles)
        {
            printf("ERROR: TOO MANY CYCLES (BAD PARAMETERS). EXITING. \n");
            return(1);
        }
        while (tend<=period_counter*Period)
        {
            solver (Arteries, tstart, tend, k, Period, WALL_MODEL, VEL_MODEL);
            sol_p2[sol_ID] = Arteries[0]->P(0,Arteries[0]->Anew[0],WALL_MODEL);
            sol_p2[sol_ID] *= rho*g*Lr/conv;
            sse = sse+ sq(sol_p1[sol_ID]-sol_p2[sol_ID]);
            tstart = tend;
            tend   = tend + Deltat; // The current ending time is increased by Deltat.
            sol_ID++;
        }
        norm_sol = sse;
        memcpy (sol_p1, sol_p2, sizeof(sol_p2));
        fflush(stdout);
//         printf("NORM OF SOLN DIFF:%f\n",norm_sol);
    }
    fflush(stdout);
//     printf("final num cylces:%d\n",period_counter);
    

    //////////////////////////////////////////////
  // The loop is continued until the final time
  // is reached. If one wants to make a plot of
  // the solution versus x, tend is set to final-
  // time in the above declaration.

  period_counter++;

    
  finaltime = (period_counter+(cycles-1))*(Period);
    while (tend <= finaltime)
    {
        for (int j=0; j<nbrves; j++)
        {
            int ArtjN = Arteries[j]->N;
            for (int i=0; i<ArtjN; i++)
            {
                Arteries[j]->Qprv[i+1] = Arteries[j]->Qnew[i+1];
                Arteries[j]->Aprv[i+1] = Arteries[j]->Anew[i+1];
            }
        }
        
        // Solves the equations until time equals tend.
        solver (Arteries, tstart, tend, k, Period, WALL_MODEL, VEL_MODEL);
        
        // A 2D plot of P(x_fixed,t) is made. The resulting 2D graph is due to
        // the while loop, since for each call of printPt only one point is set.
        // To print more vessels, use:
        //
        // Arteries[ connectivity_matrix[ROW][COL]] -> printPxt (artI, tend, 0, WALL_MODEL);
        
        
        // Prints the proximal, midpoint, and distal waveforms for
        // every vessel and combines it all to one file.
        
        for (int save_id=0; save_id<nbrves; save_id++)
         {
             Arteries[ save_id] -> printAllt (fpALL, tend, 0, WALL_MODEL);
         }
        for (int save_id=0; save_id<nbrves; save_id++)
        {
            Arteries[ save_id] -> printAllt (fpALL, tend, Arteries[save_id]->N/2, WALL_MODEL);
        }
        for (int save_id=0; save_id<nbrves; save_id++)
        {
            Arteries[ save_id] -> printAllt (fpALL, tend, Arteries[save_id]->N, WALL_MODEL);
        }
        fflush(fpALL);
//     fprintf(stdout,"t: %lf\n",tend);

        // The time within each print is increased.
        tstart = tend;
        tend   = tend + Deltat; // The current ending time is increased by Deltat.
    }
    
    // In order to termate the program correctly the vessel network and hence
    // all the vessels and their workspace are deleted.
    for (int i=0; i<nbrves; i++) delete Arteries[i];
    
    // Matrices and arrays are deleted
    for (int i=0; i<24; i++) delete[] fjac[i];
    
    // Add additional close statements if you are writing to multiple files
     fclose(fpALL);
    
    return 0;
}
