% Explore different GP settings for GP-multioutput
% ST model
% Optimisation

clear;close all

%add path to the modified GPstuff toolbox (with the changes made to
% accommodate kronecker product for multioutput GP)
addpath(genpath('/gpstuff-develop'))

addpath('/CommonFunctions')

EmulationApproach = 1; % 1: emulate whole signal, 2: emulate PCs

noBeta = 1;

if noBeta == 1
    load('ST_4par_train.mat') % no rmin, beta out
else
    load('ST_normin_train.mat') % no rmin, beta in
end

% GP testing data
if noBeta == 1
    load('ST_4par_test.mat')
else
    load('ST_normin_test.mat')
end

nd = size(par_train,2); % parameter dimensionality

% lower and upper bounds for the parameters
if noBeta == 1
    l = [8e4 -30 0.80 3];
    u = [2e5 -5 0.92 10];
    
else
    
    l = [8e4 -30 0.80 0.60 3];
    u = [2e5 -5 0.92 0.72 10];
end

% scaling factor needed for emulation
sc = max(abs(l),abs(u));

n_test=size(par_test,1); % no of test points for the GP

ntp = size(p_train(1:8:end,:),1); % no of time points

time = linspace(0,0.11,ntp); % time vector

% 1:Matern 5/2 and periodic
% 2:Matern 3/2 and periodic
% 3:Neural network and periodic
% 4:Matern 5/2 and Matern 5/2
% 5:RBF and Matern 5/2
% 6:RBF and Matern 3/2
kernel = [1,2,3,4,5,6];
jitter = [1e-04, 1e-05, 1e-06, 1e-07, 1e-08, 1e-09]; % possible jitter values
n_train_vec = [100, 1000]; % no of training points for the GP

nrun=10;
delete(gcp('nocreate'))
parpool('local', nrun)

for ki = 1:numel(kernel)
    
    for ji = 1:numel(jitter)
        
        for ti = 1:numel(n_train_vec)
            
            %% Fit emulator
            n_train = n_train_vec(ti); % no of training points
            
            x_train = par_train(1:n_train,:); % take a subset of all training points
            
            x_train = x_train./sc;
            
            pressures_train=(p_train(:,1:n_train))';
            
            pressures_train = pressures_train(:,1:8:end); % take every 8th point
            
            input_train = NaN(n_train*ntp,nd+1);
            output_train = NaN(n_train*ntp,1);
            count=0;
            for i=1:n_train
                for j=1:ntp
                    count=count+1;
                    input_train(count,:) = [x_train(i,:) time(j)];
                    output_train(count) = pressures_train(i,j);
                end
            end
            
            x=input_train;
            x1 = x_train;
            x2 = time';
            
            mean_y=mean(output_train);
            std_y=std(output_train);
            output_train=(output_train-mean_y)./std_y;
            
            H = [1 repmat(0.1,1,nd)];
            
            [gp, nlml, gp1, gp2] = GPmodel_multioutput_allSettings(input_train, ...
                output_train, H, kernel(ki), jitter(ji));
            
            %%%%
            
            %% Implement optimisation for every test data set
            
            FinalxValues = NaN(n_test,nrun,nd);
            FinalfValues = NaN(n_test,nrun,1);
            
            for iData = 1:n_test
                pressure_test = p_test(1:8:end, iData); % take every 8th point
                
                % take different initial values for the optimisation
                
                X = sobolset(nd, 'Skip',2e12,'Leap',0.95e15);
                
                n = size(X,1);
                
                x = NaN(n,nd);
                
                for i=1:nd
                    x(:,i) = l(i) + (u(i)-l(i)) * X(1:n,i);
                end
                
                % some extra parameters that are needed
                
                if EmulationApproach == 1 % 1: emulate whole signal, 2: emulate PCs
                    extra_p = {EmulationApproach, gp, x_train, output_train, ...
                        gp1, gp2, x1, x2, mean_y, std_y, ntp, nd, l, u, sc};
                else
                    extra_p = {EmulationApproach,gp_regr,x_regr,y_regr,NC,coeff,mu,...
                        mean_y,std_y,ntp,nd, l, u, sc};
                end
                
                % Run optimization and store output in structure array
                % One structure for every different parameter initialisation
                
                parfor i = 1:nrun
                    history(i) = GradientAlgorithm(x(i,:)./sc, pressure_test, extra_p);
                end
                
                for i=1:nrun
                    
                    FinalxValues(iData,i,:) = history(i).x(end,:) .* sc;
                    
                    FinalfValues(iData,i,:) = history(i).fval(end,:);
                    
                end
                
                
            end
            
        end
    end
end