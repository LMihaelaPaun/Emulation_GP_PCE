% Plot PCE FWD results
clear; clc; close all;
y_min = -16;
y_max = 10;

ftsize = 16;
g_order = [1:6];
group_pos_GP_T = [0.8:1:5.8 1.2:1:6.2];
group_pos_GP_PCA = [0.8:1:4 1.2:1:4.2];
group_pos_PCE = [0.8:1:6 1.2:1:6.2];
x_ticks_GPT = [1:1:6];
x_ticks_GPPCA = [1:1:4];
x_ticks_PCE = [1:1:6];

color = [0.3 0.3 0.3; 0.6 0.6 0.6];
color = repmat(color,16,1);
% GPtime_labels = {'$(M_{\frac{5}{2}},P)$','$(M_{\frac{3}{2}},P)$','$(NN,P)$','$(M_{\frac{5}{2}},M_{\frac{5}{2}})$','$(SE,M_{\frac{5}{2}})$','$(SE,M_{\frac{3}{2}})$'};
% GPpca_labels = {'$SE$','$M_{\frac{5}{2}}$','$M_{\frac{3}{2}}$','$NN$'};
GPtime_labels = {'(M5/2,P)','(M3/2,P)','(NN,P)','(M5/2,M5/2)','(SE,M5/2)','(SE,M3/2)'};
GPpca_labels = {'SE','M5/2','M3/2','NN'};
PCE_labels = {'$\mathcal{K}=1$','$\mathcal{K}=2$','$\mathcal{K}=3$','$\mathcal{K}=4$','$\mathcal{K}=5$','$\mathcal{K}=6$'};

%% Load data
load GP_vs_PCE_FWD_ST.mat a_PCA a_time
GP_100_PCA = squeeze(a_PCA(:,:,1));
GP_1000_PCA = squeeze(a_PCA(:,:,2));
GP_100_T = squeeze(a_time(:,:,1));
GP_1000_T = squeeze(a_time(:,:,2));

load final_validation_error/ST_time_validation_error.mat MSE
MSE_ST_T_100 = squeeze(MSE(:,1,:))';
MSE_ST_T_1000 = squeeze(MSE(:,2,:))';

load final_validation_error/ST_PCA_validation_error.mat MSE
MSE_ST_pca_100 = squeeze(MSE(:,1,:))';
MSE_ST_pca_1000 = squeeze(MSE(:,2,:))';

% MSE_ST_T_100 MSE_ST_T_1000
%% Make plot with the four results
h = figure(991); clf; %
% h.Position = [-2.3020e+02   1.0826e+03   1.2520e+03   6.7600e+02];
tiledlayout(2, 2, "TileSpacing", "compact"); 

nexttile(1); hold on;
yline(median(log(GP_100_T(6,:))),'--','Color',[0.6 0.6 0.6],'LineWidth',1.5);
yline(median(log(GP_1000_T(4,:))),'--k','LineWidth',1.5);
boxplot(log([GP_100_T' GP_1000_T']),'Positions',group_pos_GP_T,'Widths',0.3); 
% rectangle('Position',[group_pos_GP_T(6)-0.4,y_min+0.3,0.8,21.2],'LineWidth',1, 'LineStyle','-.', 'Curvature',[1,1])
% rectangle('Position',[group_pos_GP_T(10)-0.4,y_min+0.3,0.8,21.2],'LineWidth',1, 'LineStyle','-.')

ylim([y_min y_max]);
h = findobj(gca,'Tag','Box'); 
for j=1:length(h) 
    if mod(j,2)==1
    patch(get(h(j),'XData'),get(h(j),'YData'),color(j,:),'FaceAlpha',.65);
    end
end 
plot(group_pos_GP_T(6),5,'k*','MarkerSize',12,'LineWidth',2)
plot(group_pos_GP_T(10),5,'^','MarkerSize',12,'MarkerEdgeColor',[0.6 0.6 0.6],...
    'MarkerFaceColor',[0.5 0.5 0.5],'LineWidth',2)
xticks(x_ticks_GPT)
title('GP.time','Interpreter','latex'); grid on; set(gca,'FontSize',20,'TickLabelInterpreter','latex');
ylabel('Log(MSE)','Interpreter','latex')
xticklabels(GPtime_labels); xtickangle(45)
xlim([0.6 6.4])
%%
nexttile(2); hold on;
yline(median(log(GP_100_PCA(1,:))),'--','Color',[0.6 0.6 0.6],'LineWidth',1.5);
yline(median(log(GP_1000_PCA(2,:))),'--k','LineWidth',1.5);
boxplot(log([GP_100_PCA' GP_1000_PCA']),'Positions',group_pos_GP_PCA,'Widths',0.3);
% rectangle('Position',[group_pos_GP_PCA(1)-0.4,y_min+0.3,0.8,21.2],'LineWidth',1, 'LineStyle','-.', 'Curvature',[1,1])
% rectangle('Position',[group_pos_GP_PCA(6)-0.4,y_min+0.3,0.8,21.2],'LineWidth',2)
ylim([y_min y_max]);
h = findobj(gca,'Tag','Box'); 
for j=1:length(h) 
    if mod(j,2)==1
    patch(get(h(j),'XData'),get(h(j),'YData'),color(j,:),'FaceAlpha',.65);
    end
end 
plot(group_pos_GP_PCA(1),6,'k*','MarkerSize',12,'LineWidth',2)
plot(group_pos_GP_PCA(6),6,'^','MarkerSize',12,'MarkerEdgeColor',[0.6 0.6 0.6],...
    'MarkerFaceColor',[0.5 0.5 0.5],'LineWidth',2)
title('GP.PCA','Interpreter','latex'); grid on; set(gca,'FontSize',20,'TickLabelInterpreter','latex');
% ylabel('Log(MSE)','Interpreter','latex')
xticklabels(GPpca_labels)
xticks(x_ticks_GPPCA); xtickangle(45)
yticklabels('')
xlim([0.6 4.4])
%%
nexttile(3); hold on;
% yline(median(log(MSE_ST_T_100(1,:))),'--','Color',[0.6 0.6 0.6],'LineWidth',1.5);
% yline(median(log(MSE_ST_T_1000(2,:))),'--k','LineWidth',1.5);
yline(median(log(GP_100_T(6,:))),'--','Color',[0.6 0.6 0.6],'LineWidth',1.5);
yline(median(log(GP_1000_T(4,:))),'--k','LineWidth',1.5);
boxplot(log([MSE_ST_T_100 MSE_ST_T_1000]),'Positions',group_pos_PCE,'Widths',0.3);
% rectangle('Position',[group_pos_PCE(1)-0.4,y_min+0.3,0.8,21.2],'LineWidth',1, 'LineStyle','-.', 'Curvature',[1,1])
% rectangle('Position',[group_pos_PCE(6)-0.4,y_min+0.3,0.8,21.2],'LineWidth',2)
ylim([y_min y_max]);
h = findobj(gca,'Tag','Box'); 
for j=1:length(h) 
    if mod(j,2)==1
    patch(get(h(j),'XData'),get(h(j),'YData'),color(j,:),'FaceAlpha',.65);
    end
end 
plot(group_pos_PCE(3),6,'k*','MarkerSize',12,'LineWidth',2)
plot(group_pos_PCE(12),6,'^','MarkerSize',12,'MarkerEdgeColor',[0.6 0.6 0.6],...
    'MarkerFaceColor',[0.5 0.5 0.5],'LineWidth',2)
title('PCE.time','Interpreter','latex'); grid on; set(gca,'FontSize',20,'TickLabelInterpreter','latex');
ylabel('Log(MSE)','Interpreter','latex')
xticklabels(PCE_labels)
xticks(x_ticks_PCE); xtickangle(45)
xlim([0.6 6.4])
%%
nexttile(4); hold on;   
% yline(median(log(MSE_ST_pca_100(1,:))),'--','Color',[0.6 0.6 0.6],'LineWidth',1.5);
% yline(median(log(MSE_ST_pca_1000(2,:))),'--k','LineWidth',1.5);
yline(median(log(GP_100_PCA(1,:))),'--','Color',[0.6 0.6 0.6],'LineWidth',1.5);
yline(median(log(GP_1000_PCA(2,:))),'--k','LineWidth',1.5);
boxplot(log([MSE_ST_pca_100 MSE_ST_pca_1000]),'Positions',group_pos_PCE,'Widths',0.3);
ylim([y_min y_max]);
h = findobj(gca,'Tag','Box'); 
for j=1:length(h) 
    if mod(j,2)==1
    patch(get(h(j),'XData'),get(h(j),'YData'),color(j,:),'FaceAlpha',.65);
    end
end 
title('PCE.PCA','Interpreter','latex'); grid on; set(gca,'FontSize',20,'TickLabelInterpreter','latex');
yticklabels('');
% ylabel('Log(MSE)','Interpreter','latex')
plot(group_pos_PCE(3),6,'k*','MarkerSize',12,'LineWidth',2)
plot(group_pos_PCE(12),6,'^','MarkerSize',12,'MarkerEdgeColor',[0.6 0.6 0.6],...
    'MarkerFaceColor',[0.5 0.5 0.5],'LineWidth',2)
xticks(x_ticks_PCE); xtickangle(45)
xticklabels(PCE_labels)
xlim([0.6 6.4])
ha = annotation('textbox',[0.01 0.89 0.06 0.1],'string','ST','FontSize',20,'FitBoxToText','on');
ha.HorizontalAlignment = 'center';
% set(gcf,'Position',[-1.0054e+03   1.0802e+03   1.3984e+03   6.5680e+02])
%% Load data
load GP_vs_PCE_FWD_WK.mat a_PCA a_time
GP_100_PCA = squeeze(a_PCA(:,:,1));
GP_1000_PCA = squeeze(a_PCA(:,:,2));
GP_100_T = squeeze(a_time(:,:,1));
GP_1000_T = squeeze(a_time(:,:,2));

load final_validation_error/WK_time_validation_error.mat MSE
MSE_WK_T_100 = squeeze(MSE(:,1,:))';
MSE_WK_T_1000 = squeeze(MSE(:,2,:))';

load final_validation_error/WK_PCA_validation_error.mat MSE
MSE_WK_pca_100 = squeeze(MSE(:,1,:))';
MSE_WK_pca_1000 = squeeze(MSE(:,2,:))';


%% Make plot with the four results
h = figure(992); clf; %
% h.Position = [-2.3020e+02   1.0826e+03   1.2520e+03   6.7600e+02];
tiledlayout(2, 2, "TileSpacing", "compact"); 

nexttile(1); hold on;
yline(min(median(log(GP_100_T'))),'--','Color',[0.6 0.6 0.6],'LineWidth',1.5);
yline(min(median(log(GP_1000_T'))),'--k','LineWidth',1.5);
boxplot(log([GP_100_T' GP_1000_T']),'Positions',group_pos_GP_T,'Widths',0.3); 
% rectangle('Position',[group_pos_GP_T(6)-0.4,y_min+0.3,0.8,21.2],'LineWidth',1, 'LineStyle','-.', 'Curvature',[1,1])
% rectangle('Position',[group_pos_GP_T(10)-0.4,y_min+0.3,0.8,21.2],'LineWidth',1, 'LineStyle','-.')
ylim([y_min y_max]);
h = findobj(gca,'Tag','Box'); 
for j=1:length(h) 
    if mod(j,2)==1
    patch(get(h(j),'XData'),get(h(j),'YData'),color(j,:),'FaceAlpha',.65);
    end
end 
plot(group_pos_GP_T(1),6,'k*','MarkerSize',12,'LineWidth',2)
plot(group_pos_GP_T(9),6,'^','MarkerSize',12,'MarkerEdgeColor',[0.6 0.6 0.6],...
    'MarkerFaceColor',[0.5 0.5 0.5],'LineWidth',2)
xticks(x_ticks_GPT)
title('GP.time','Interpreter','latex'); grid on; set(gca,'FontSize',20,'TickLabelInterpreter','latex');
ylabel('Log(MSE)','Interpreter','latex')
xticklabels(GPtime_labels); xtickangle(45)
xlim([0.6 6.4])

%%
nexttile(2); hold on;
yline(min(median(log(GP_100_PCA'))),'--','Color',[0.6 0.6 0.6],'LineWidth',1.5);
yline(min(median(log(GP_1000_PCA'))),'--k','LineWidth',1.5);
boxplot(log([GP_100_PCA' GP_1000_PCA']),'Positions',group_pos_GP_PCA,'Widths',0.3);
% rectangle('Position',[group_pos_GP_PCA(1)-0.4,y_min+0.3,0.8,21.2],'LineWidth',1, 'LineStyle','-.', 'Curvature',[1,1])
% rectangle('Position',[group_pos_GP_PCA(6)-0.4,y_min+0.3,0.8,21.2],'LineWidth',2)
ylim([y_min y_max]);
h = findobj(gca,'Tag','Box'); 
for j=1:length(h) 
    if mod(j,2)==1
    patch(get(h(j),'XData'),get(h(j),'YData'),color(j,:),'FaceAlpha',.65);
    end
end 
plot(group_pos_GP_PCA(2),6,'k*','MarkerSize',12,'LineWidth',2)
plot(group_pos_GP_PCA(8),6,'^','MarkerSize',12,'MarkerEdgeColor',[0.6 0.6 0.6],...
    'MarkerFaceColor',[0.5 0.5 0.5],'LineWidth',2)
title('GP.PCA','Interpreter','latex'); grid on; set(gca,'FontSize',20,'TickLabelInterpreter','latex');
xticks(x_ticks_GPPCA)
xticklabels(GPpca_labels); xtickangle(45)
yticklabels('');
xlim([0.6 4.4])

%%
nexttile(3); hold on;
yline(min(median(log(GP_100_T'))),'--','Color',[0.6 0.6 0.6],'LineWidth',1.5);
yline(min(median(log(GP_1000_T'))),'--k','LineWidth',1.5);
boxplot(log([MSE_WK_pca_100 MSE_WK_pca_1000]),'Positions',group_pos_PCE,'Widths',0.3);
% rectangle('Position',[group_pos_GP_PCA(1)-0.4,y_min+0.3,0.8,21.2],'LineWidth',1, 'LineStyle','-.', 'Curvature',[1,1])
% rectangle('Position',[group_pos_GP_PCA(6)-0.4,y_min+0.3,0.8,21.2],'LineWidth',2)
ylim([y_min y_max]);
h = findobj(gca,'Tag','Box'); 
for j=1:length(h) 
    if mod(j,2)==1
    patch(get(h(j),'XData'),get(h(j),'YData'),color(j,:),'FaceAlpha',.65);
    end
end 
plot(group_pos_PCE(3),6,'k*','MarkerSize',12,'LineWidth',2)
plot(group_pos_PCE(12),6,'^','MarkerSize',12,'MarkerEdgeColor',[0.6 0.6 0.6],...
    'MarkerFaceColor',[0.5 0.5 0.5],'LineWidth',2)
title('PCE.time','Interpreter','latex'); grid on; set(gca,'FontSize',20,'TickLabelInterpreter','latex');
ylabel('Log(MSE)','Interpreter','latex')
xticks(x_ticks_PCE);
xticklabels(PCE_labels); xtickangle(45)
xlim([0.6 6.4])
%%
nexttile(4); hold on;   
yline(min(median(log(GP_100_PCA'))),'--','Color',[0.6 0.6 0.6],'LineWidth',1.5);
yline(min(median(log(GP_1000_PCA'))),'--k','LineWidth',1.5);
boxplot(log([MSE_WK_T_100 MSE_WK_T_1000]),'Positions',group_pos_PCE,'Widths',0.3);
ylim([y_min y_max]);
h = findobj(gca,'Tag','Box'); 
for j=1:length(h) 
    if mod(j,2)==1
    patch(get(h(j),'XData'),get(h(j),'YData'),color(j,:),'FaceAlpha',.65);
    end
end 
plot(group_pos_PCE(3),6,'k*','MarkerSize',12,'LineWidth',2)
plot(group_pos_PCE(12),6,'^','MarkerSize',12,'MarkerEdgeColor',[0.6 0.6 0.6],...
    'MarkerFaceColor',[0.5 0.5 0.5],'LineWidth',2)
title('PCE.PCA','Interpreter','latex'); grid on; set(gca,'FontSize',20,'TickLabelInterpreter','latex');
yticklabels('');
xticks(x_ticks_PCE);
xticklabels(PCE_labels); xtickangle(45)
xlim([0.6 6.4])
ha = annotation('textbox',[0.01 0.89 0.06 0.1],'string','WK','FontSize',20,'FitBoxToText','on');
ha.HorizontalAlignment = 'center';
% set(gcf,'Position',[  -1.0054e+03   1.0802e+03   1.3984e+03   6.5680e+02])