% Plot PCE FWD results
clear; clc; close all;
y_min = -16;
y_max = 12;
% rmpath('../../DRAM/')
ftsize = 16;
g_order = [2,3,4,5,6];
plot_groups1 = {0.8,2.8,4.8,5.8,8.8};
plot_groups2 = {1.2,3.2,5.2,7.2,9.2};
plot_groups3 = {1,3,5,7,9,2,4,6,8,10};
group_pos = [1 2 4 5 7 8 10 11 13 14];
color = [0.3 0.3 0.3; 0.6 0.6 0.6];
color = repmat(color,10,1);
time_labels = {'GP.time.100','GP.time.1000','PCE.time.100','PCE.time.1000'};
pca_labels = {'GP.PCA.100','GP.PCA.1000','PCE.PCA.100','PCE.PCA.1000'};

%% Load data
load data_figure2_ST.mat
%% Make plot with the four results
h = figure(991); clf; %
% h.Position = [-2.3020e+02   1.0826e+03   1.2520e+03   6.7600e+02];
tiledlayout(3, 2, "TileSpacing", "compact"); 
%% Forward Evaluation
%%
nexttile(1); hold on;
yline(median(log(bestMSE_multi(2,:)')),'-.k','LineWidth',1.5);
boxplot(log([bestMSE_multi(1,:)' bestMSE_multi(2,:)' ...
            MSE_ST_T_100(:,3) MSE_ST_T_1000(:,5)]));%,plot_groups3,'Positions',group_pos); 
ylim([y_min y_max]);
h = findobj(gca,'Tag','Box'); 
for j=1:length(h) 
    if mod(j,2)==1
    patch(get(h(j),'XData'),get(h(j),'YData'),color(j,:),'FaceAlpha',.65);
    end
end 
plot(1,8.5,'k*','MarkerSize',20,'LineWidth',2)
plot(2,8.5,'^','MarkerSize',20,'MarkerEdgeColor',[0.6 0.6 0.6],...
    'MarkerFaceColor',[0.5 0.5 0.5],'LineWidth',2)
title('Output Error','Interpreter','latex'); grid on; set(gca,'FontSize',16,'TickLabelInterpreter','latex');
ylabel({'Forward Problem:'; 'Log(MSE)'},'Interpreter','latex')
xticklabels('')
%%
nexttile(2); hold on;
yline(median(log(bestMSE_PCA(2,:)')),'-.k','LineWidth',1.5);
boxplot(log([bestMSE_PCA(1,:)' bestMSE_PCA(2,:)' ...
            MSE_ST_pca_100(:,3) MSE_ST_pca_1000(:,5)]));%,plot_groups3,'Positions',group_pos); 
ylim([y_min y_max]);
h = findobj(gca,'Tag','Box'); 
for j=1:length(h) 
    if mod(j,2)==1
    patch(get(h(j),'XData'),get(h(j),'YData'),color(j,:),'FaceAlpha',.65);
    end
end 
plot(1,8.5,'k*','MarkerSize',20,'LineWidth',2)
plot(2,8.5,'^','MarkerSize',20,'MarkerEdgeColor',[0.6 0.6 0.6],...
    'MarkerFaceColor',[0.5 0.5 0.5],'LineWidth',2)
title('Output Error','Interpreter','latex'); grid on; set(gca,'FontSize',16,'TickLabelInterpreter','latex');
yticklabels(''); xticklabels('')

%% Ouput space: Inverse Problem
nexttile(3); hold on;
yline(median(log(bestRSEinput_multi(2,:)')),'-.k','LineWidth',1.5);
boxplot(log([bestRSEinput_multi(1,:)' bestRSEinput_multi(2,:)' ...
            par_err_T_ST_n100 par_err_T_ST_n1000]));%,plot_groups3,'Positions',group_pos); 
ylim([y_min y_max]);
h = findobj(gca,'Tag','Box'); 
for j=1:length(h) 
    if mod(j,2)==1
    patch(get(h(j),'XData'),get(h(j),'YData'),color(j,:),'FaceAlpha',.65);
    end
end 
plot(1,8.5,'k*','MarkerSize',20,'LineWidth',2)
plot(2,8.5,'^','MarkerSize',20,'MarkerEdgeColor',[0.6 0.6 0.6],...
    'MarkerFaceColor',[0.5 0.5 0.5],'LineWidth',2)
title('Parameter Error','Interpreter','latex'); grid on; set(gca,'FontSize',16,'TickLabelInterpreter','latex');
ylabel({'Inverse Problem:'; 'Log(RSE)'},'Interpreter','latex')
xticklabels('')
%%
nexttile(4); hold on;
% yline(median(log(bestRSEinput_PCA(2,:)')),'-.k','LineWidth',1.5);
yline(median(log(par_err_PCA_ST_n1000)),'-.k','LineWidth',1.5);
boxplot(log([bestRSEinput_PCA(1,:)' bestRSEinput_PCA(2,:)' ...
            par_err_PCA_ST_n100 par_err_PCA_ST_n1000]));%,plot_groups3,'Positions',group_pos); 
ylim([y_min y_max]);
h = findobj(gca,'Tag','Box'); 
for j=1:length(h) 
    if mod(j,2)==1
    patch(get(h(j),'XData'),get(h(j),'YData'),color(j,:),'FaceAlpha',.65);
    end
end 
plot(1,8.5,'k*','MarkerSize',20,'LineWidth',2)
plot(4,8.5,'^','MarkerSize',20,'MarkerEdgeColor',[0.6 0.6 0.6],...
    'MarkerFaceColor',[0.5 0.5 0.5],'LineWidth',2)
title('Parameter Error','Interpreter','latex'); grid on; set(gca,'FontSize',16,'TickLabelInterpreter','latex');
yticklabels(''); xticklabels('')
% ylabel('Log(RSE)','Interpreter','latex')
%%
nexttile(5); hold on;
yline(median(log(bestMSEoutput_multi(2,:)')),'-.k','LineWidth',1.5);
boxplot(log([bestMSEoutput_multi(1,:)' bestMSEoutput_multi(2,:)' ...
             MSE_sim_T_ST_n100 MSE_sim_T_ST_n1000]));%,plot_groups3,'Positions',group_pos); 
ylim([y_min y_max]);
h = findobj(gca,'Tag','Box'); 
for j=1:length(h) 
    if mod(j,2)==1
    patch(get(h(j),'XData'),get(h(j),'YData'),color(j,:),'FaceAlpha',.65);
    end
end 
plot(1,8.5,'k*','MarkerSize',20,'LineWidth',2)
plot(2,8.5,'^','MarkerSize',20,'MarkerEdgeColor',[0.6 0.6 0.6],...
    'MarkerFaceColor',[0.5 0.5 0.5],'LineWidth',2)
title('Output Error','Interpreter','latex'); grid on; set(gca,'FontSize',16,'TickLabelInterpreter','latex');
ylabel('Log(MSE)','Interpreter','latex')
xticklabels(time_labels);
%%
nexttile(6); hold on;   
yline(median(log(bestMSEoutput_PCA(2,:)')),'-.k','LineWidth',1.5);
boxplot(log([bestMSEoutput_PCA(1,:)' bestMSEoutput_PCA(2,:)' ...
             MSE_sim_PCA_ST_n100 MSE_sim_PCA_ST_n1000]));%,plot_groups3,'Positions',group_pos); 
ylim([y_min y_max]);
h = findobj(gca,'Tag','Box'); 
for j=1:length(h) 
    if mod(j,2)==1
    patch(get(h(j),'XData'),get(h(j),'YData'),color(j,:),'FaceAlpha',.65);
    end
end 
plot(1,8.5,'k*','MarkerSize',20,'LineWidth',2)
plot(2,8.5,'^','MarkerSize',20,'MarkerEdgeColor',[0.6 0.6 0.6],...
    'MarkerFaceColor',[0.5 0.5 0.5],'LineWidth',2)
title('Output Error','Interpreter','latex'); grid on; set(gca,'FontSize',16,'TickLabelInterpreter','latex');
yticklabels('');
% ylabel('Log(MSE)','Interpreter','latex')
xticklabels(pca_labels);
ha = annotation('textbox',[0.01 0.89 0.06 0.1],'string','ST','FontSize',16,'FitBoxToText','on');
ha.HorizontalAlignment = 'center';
% print('ST_Fig3.pdf','-depsc')
% pause(1)
%% Load data
load data_figure2_WK.mat
%% Make plot with the four results
h = figure(992); clf; %
% h.Position = [-2.3020e+02   1.0826e+03   1.2520e+03   6.7600e+02];

tiledlayout(3, 2, "TileSpacing", "compact");
%% Forward Evaluation
%%
nexttile(1); hold on;
yline(median(log(bestMSE_multi(2,:)')),'-.k','LineWidth',1.5);
boxplot(log([bestMSE_multi(1,:)' bestMSE_multi(2,:)' ...
            MSE_WK_T_100(:,3) MSE_WK_T_1000(:,5)]));%,plot_groups3,'Positions',group_pos); 
ylim([y_min y_max]);
h = findobj(gca,'Tag','Box'); 
for j=1:length(h) 
    if mod(j,2)==1
    patch(get(h(j),'XData'),get(h(j),'YData'),color(j,:),'FaceAlpha',.65);
    end
end 
plot(1,8.5,'k*','MarkerSize',20,'LineWidth',2)
plot(2,8.5,'^','MarkerSize',20,'MarkerEdgeColor',[0.6 0.6 0.6],...
    'MarkerFaceColor',[0.5 0.5 0.5],'LineWidth',2)
title('Output Error','Interpreter','latex'); grid on; set(gca,'FontSize',16,'TickLabelInterpreter','latex');
ylabel({'Forward Problem:'; 'Log(MSE)'},'Interpreter','latex')
xticklabels('')
%%
nexttile(2); hold on;
yline(median(log(bestMSE_PCA(2,:)')),'-.k','LineWidth',1.5);
boxplot(log([bestMSE_PCA(1,:)' bestMSE_PCA(2,:)' ...
            MSE_WK_pca_100(:,3) MSE_WK_pca_1000(:,5)]));%,plot_groups3,'Positions',group_pos); 
ylim([y_min y_max]);
h = findobj(gca,'Tag','Box'); 
for j=1:length(h) 
    if mod(j,2)==1
    patch(get(h(j),'XData'),get(h(j),'YData'),color(j,:),'FaceAlpha',.65);
    end
end 
plot(1,8.5,'k*','MarkerSize',20,'LineWidth',2)
plot(2,8.5,'^','MarkerSize',20,'MarkerEdgeColor',[0.6 0.6 0.6],...
    'MarkerFaceColor',[0.5 0.5 0.5],'LineWidth',2)
title('Output Error','Interpreter','latex'); grid on; set(gca,'FontSize',16,'TickLabelInterpreter','latex');
yticklabels(''); xticklabels('')

%% Ouput space: Inverse Problem
nexttile(3); hold on;
yline(median(log(bestRSEinput_multi(2,:)')),'-.k','LineWidth',1.5);
boxplot(log([bestRSEinput_multi(1,:)'  bestRSEinput_multi(2,:)'...
             par_err_T_WK_n100 par_err_T_WK_n1000]));%,plot_groups3,'Positions',group_pos); 
ylim([y_min y_max]);
h = findobj(gca,'Tag','Box'); 
for j=1:length(h) 
    if mod(j,2)==1
    patch(get(h(j),'XData'),get(h(j),'YData'),color(j,:),'FaceAlpha',.65);
    end
end 
plot(1,8.5,'k*','MarkerSize',20,'LineWidth',2)
plot(2,8.5,'^','MarkerSize',20,'MarkerEdgeColor',[0.6 0.6 0.6],...
    'MarkerFaceColor',[0.5 0.5 0.5],'LineWidth',2)
title('Parameter Error','Interpreter','latex'); grid on; set(gca,'FontSize',16,'TickLabelInterpreter','latex');
ylabel({'Inverse Problem:'; 'Log(RSE)'},'Interpreter','latex')
xticklabels('')
%%
nexttile(4); hold on;
yline(median(log(bestRSEinput_PCA(2,:)')),'-.k','LineWidth',1.5);
boxplot(log([bestRSEinput_PCA(1,:)' bestRSEinput_PCA(2,:)' ...
             par_err_PCA_WK_n100 par_err_PCA_WK_n1000]));%,plot_groups3,'Positions',group_pos); 
ylim([y_min y_max]);
h = findobj(gca,'Tag','Box'); 
for j=1:length(h) 
    if mod(j,2)==1
    patch(get(h(j),'XData'),get(h(j),'YData'),color(j,:),'FaceAlpha',.65);
    end
end 
plot(1,8.5,'k*','MarkerSize',20,'LineWidth',2)
plot(2,8.5,'^','MarkerSize',20,'MarkerEdgeColor',[0.6 0.6 0.6],...
    'MarkerFaceColor',[0.5 0.5 0.5],'LineWidth',2)
title('Parameter Error','Interpreter','latex'); grid on; set(gca,'FontSize',16,'TickLabelInterpreter','latex');
yticklabels(''); xticklabels('')
%%
nexttile(5); hold on;
yline(median(log(bestMSEoutput_multi(2,:)')),'-.k','LineWidth',1.5);
boxplot(log([bestMSEoutput_multi(1,:)' bestMSEoutput_multi(2,:)'...
            MSE_sim_T_WK_n100 MSE_sim_T_WK_n1000]));%,plot_groups3,'Positions',group_pos); 
ylim([y_min y_max]);
h = findobj(gca,'Tag','Box'); 
for j=1:length(h) 
    if mod(j,2)==1
    patch(get(h(j),'XData'),get(h(j),'YData'),color(j,:),'FaceAlpha',.65);
    end
end 
plot(1,8.5,'k*','MarkerSize',20,'LineWidth',2)
plot(2,8.5,'^','MarkerSize',20,'MarkerEdgeColor',[0.6 0.6 0.6],...
    'MarkerFaceColor',[0.5 0.5 0.5],'LineWidth',2)
title('Output Error','Interpreter','latex'); grid on; set(gca,'FontSize',16,'TickLabelInterpreter','latex');
ylabel('Log(MSE)','Interpreter','latex')
xticklabels(time_labels);
%%
nexttile(6); hold on;
yline(median(log(bestMSEoutput_PCA(2,:)')),'-.k','LineWidth',1.5);
boxplot(log([bestMSEoutput_PCA(1,:)' bestMSEoutput_PCA(2,:)' ...
            MSE_sim_PCA_WK_n100 MSE_sim_PCA_WK_n1000]));%,plot_groups3,'Positions',group_pos); 
ylim([y_min y_max]);
h = findobj(gca,'Tag','Box'); 
for j=1:length(h) 
    if mod(j,2)==1
    patch(get(h(j),'XData'),get(h(j),'YData'),color(j,:),'FaceAlpha',.65);
    end
end 
plot(1,8.5,'k*','MarkerSize',20,'LineWidth',2)
plot(2,8.5,'^','MarkerSize',20,'MarkerEdgeColor',[0.6 0.6 0.6],...
    'MarkerFaceColor',[0.5 0.5 0.5],'LineWidth',2)
title('Output Error','Interpreter','latex'); grid on; set(gca,'FontSize',16,'TickLabelInterpreter','latex');
yticklabels('');
xticklabels(pca_labels);
ha = annotation('textbox',[0.01 0.89 0.06 0.1],'string','WK','FontSize',16,'FitBoxToText','on');
ha.HorizontalAlignment = 'center';