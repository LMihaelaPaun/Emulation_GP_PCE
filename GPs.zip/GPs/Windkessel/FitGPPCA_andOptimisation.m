% Explore different GP settings for GP-PCA
% WK model
% Optimisation

clear; close all

% add path to the original GPstuff toolbox (without the changes made to
% accommodate kronecker product for multioutput GP)
addpath(genpath('/GPstuff-4.7'))

addpath('/CommonFunctions')

% load PCA results based on full training set (1900 points)
% and 5 parameters for WK
load('PCAresults_WK_noPar 5.mat')

EmulationApproach = 2; % 1: emulate whole signal, 2: emulate PCs

noPar = 5; % 4, 5, 6

% load the training data
if noPar==4
    load('WK_4par_train.mat')
elseif noPar==5
    load('WK_5par_train_new.mat')
else
    load('WK_6par_train.mat')
end

% GP testing data
if noPar==4
    load('WK_4par_test.mat')
elseif noPar==5
    load('WK_5par_test.mat')
else
    load('WK_6par_test.mat')
end

nd = size(par_train,2); % parameter dimensionality

% lower and upper bounds for the parameters
l = [3e4 -30 0.05 0.05 0.05];
u = [2e5 -5 3 3 3];

% scaling factor needed for emulation
sc = max(abs(l),abs(u));

n_test=size(par_test,1); % no of test points for the GP

ntp = size(p_train(1:8:end,:),1); % no of time points

kernel = [1,2,3,4]; % 1: RBF, 2: Matern 5/2, 3: Matern 3/2, 4: neural network
jitter = [1e-04, 1e-05, 1e-06, 1e-07, 1e-08, 1e-09]; % possible jitter values
n_train_vec = [100, 1000]; % no of training points for the GP

nrun=10;
delete(gcp('nocreate'))
parpool('local', nrun)

for ki = 1:numel(kernel)
    
    for ji = 1:numel(jitter)
        
        for ti = 1:numel(n_train_vec)
            
            %% Fit emulator
            
            n_train = n_train_vec(ti); % no of training points
            
            x_train = par_train(1:n_train,:); % take a subset of all training points
            
            x_train = x_train./sc;
            
            pressures_train=(p_train(:,1:n_train))';
            
            pressures_train = pressures_train(:,1:8:end); % take every 8th point
            
            % Now emulate the PC scores for the GP training set with independent GPs for score(:,1:NC)
            x_regr = x_train;
            y_regr = (pressures_train - mu)*coeff(:, 1:NC); % using only the first NC PCs
            
            H = [1 repmat(0.1,1,nd)];
            
            % Fit independent GPs for every PC score
            for i=1:NC
                mean_y(i) = mean(y_regr(:,i));
                std_y(i) = std(y_regr(:,i));
                
                % Scale y_regr
                y_regr(:,i) = (y_regr(:,i)-mean_y(i))./std_y(i); % mean 0 and std 1 of of y
                
                % Fit GP
                gp_regr{i} = GPmodel_PCA_allSettings(x_regr, y_regr(:,i), H, ...
                    kernel(ki), jitter(ji));
                
            end
            
            %%%%
            
            %% Implement optimisation for every test data set
            
            FinalxValues = NaN(n_test,nrun,nd);
            FinalfValues = NaN(n_test,nrun,1);
            
            for iData = 1:n_test
                pressure_test = p_test(1:8:end, iData); % take every 8th point
                
                % take different initial values for the optimisation
                
                X = sobolset(nd, 'Skip',2e12,'Leap',0.95e15);
                
                n = size(X,1);
                
                x = NaN(n,nd);
                
                for i=1:nd
                    x(:,i) = l(i) + (u(i)-l(i)) * X(1:n,i);
                end
                
                % some extra parameters that are needed
                
                if EmulationApproach == 1 % 1: emulate whole signal, 2: emulate PCs
                    extra_p = {EmulationApproach, gp, x_train, output_train, ...
                        gp1, gp2, x1, x2, mean_y, std_y, ntp, nd, l, u, sc};
                else
                    extra_p = {EmulationApproach,gp_regr,x_regr,y_regr,NC,coeff,mu,...
                        mean_y,std_y,ntp,nd, l, u, sc};
                end
                
                % Run optimization and store output in structure array
                % One structure for every different parameter initialisation
                
                parfor i = 1:nrun
                    history(i) = GradientAlgorithm(x(i,:)./sc, pressure_test, extra_p);
                end
                
                for i=1:nrun
                    
                    FinalxValues(iData,i,:) = history(i).x(end,:) .* sc;
                    
                    FinalfValues(iData,i,:) = history(i).fval(end,:);
                    
                end
                
                
            end
        end
    end
end