function [ObjFct,pressure] = objective_function_Time(param, data,myPCE,sc,id) %param is scaled

truePressure  = data;

if ~isempty(id)
    param(id) = param(id).*-1;
end

% obtain pressure with emulator for param
pressure = uq_evalModel(myPCE,param.*sc);
    
% calculate RSS
ObjFct = sum((pressure(:)-truePressure(:)).^2);
end
