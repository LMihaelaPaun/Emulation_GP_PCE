function [ObjFct,pressure] = objective_function_PCA(param, data,myPCE,sc,id, pca_mu,pca_coeff) %param is scaled

truePressure  = data;

if ~isempty(id)
    param(id) = param(id).*-1;
end

% obtain pressure with emulator for param
pressure = uq_evalModel(myPCE,param);
pressure = pressure*pca_coeff'+pca_mu;
    
% calculate RSS
ObjFct = sum((pressure(:)-truePressure(:)).^2);

end
