Using GPstuff from R
--------------------

GPstuff can be used from R by using RcppOctave package. RcppOctave
allows to call any Octave functions and browse their documentation
from R, and pass variables between R and Octave.

See instructions at
<http://research.cs.aalto.fi/pml/software/gpstuff/rgpstuff.shtml>
